<?php
 session_start();
include"includes/config.php";
include"includes/checklogin.php";
include"includes/my.php";
$page="Hostel Registration Details";

if (!isset($mylname)){
	include 'includes/failed.php';
}else{
?>

<?php include 'includes/head.php';?>
<?php include 'includes/pages/hostel_records.php';?>
<?php include 'includes/javascripts.php';?>
<?php }?>
</body>
</html>