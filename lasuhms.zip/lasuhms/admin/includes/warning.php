<section class="content">

      <div class="error-page">
        <h2 class="headline text-red">500</h2>

        <div class="error-content">
          <h3><i class="fa fa-warning text-red"></i> Oops! You are not authorized to view this page.</h3>
<?php 
if ($designation="admin") {
	$designationfull="Super Admin";
	}
if ($designation="sec"){
		$designationfull="Secretary";
		}
if($designation="hman"){
			$designationfull="Hostel Manager";
			}

?>
          <p>
            Your Designation is <?php echo $designationfull;?>, You are not allowed  to carry out this function or see the content of this page. Consult the Super Administrator to have access
            Please return to<a href="../admin-profile.php"> HomePage</a>
          </p>


        </div>
      </div>
      <!-- /.error-page -->

    </section>