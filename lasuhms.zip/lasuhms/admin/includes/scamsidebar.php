<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			 
				<li class="ts-label">Error</li>
					 
					 <br />
					 <br />
					 <br />
					 <br />
					 <br /><br />
					 <br />
					 <br />
					 <br />
					 <br /><br />
					 <br />
					 <br />
					 <br />
					 <br />
					 
		<div class="foot"><footer>
<p>&copy;<?php  echo date('Y');?><a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>

<style> .foot{color:#fff; text-align: center;}</style>
		</nav>
		