<?php
include('config.php');

$result ="SELECT count(*) FROM hostel";
$stmt =$mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($hostelcount);
$stmt->fetch();
$stmt->close();

$good='Good';
$result ="SELECT count(*) FROM hostel WHERE status=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$good);
$stmt->execute();
$stmt->bind_result($gcount);
$stmt->fetch();
$stmt->close();

$damage="Damaged";
$result ="SELECT count(*) FROM hostel WHERE status=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$damaged);
$stmt->execute();
$stmt->bind_result($dcount);
$stmt->fetch();
$stmt->close();

$official="Official";
$result ="SELECT count(*) FROM hostel WHERE status=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$official);
$stmt->execute();
$stmt->bind_result($ocount);
$stmt->fetch();
$stmt->close();

$type="PDS halls";
$result ="SELECT count(*) FROM hostel WHERE block_type=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$type);
$stmt->execute();
$stmt->bind_result($pdscount);
$stmt->fetch();
$stmt->close();

$type="New Hostels";
$result ="SELECT count(*) FROM hostel WHERE block_type=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$type);
$stmt->execute();
$stmt->bind_result($nhcount);
$stmt->fetch();
$stmt->close();

$type="Old Hostels";
$result ="SELECT count(*) FROM hostel WHERE block_type=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$type);
$stmt->execute();
$stmt->bind_result($ohcount);
$stmt->fetch();
$stmt->close();

$qry="SELECT SUM(seater) as count FROM hostel WHERE status='Good'";
$res=$mysqli->query($qry);
$totalseatercount=0;
$rec=$row=$res->fetch_assoc();
$totalseatercount=$rec['count'];

$qry="SELECT SUM(seater) as count FROM hostel WHERE status='Good' and sex='Female'";
$res=$mysqli->query($qry);
$totalseaterfmcount=0;
$rec=$row=$res->fetch_assoc();
$totalseaterfmcount=$rec['count'];

$qry="SELECT SUM(seater) as count FROM hostel WHERE status='Good' and sex='Male'";
$res=$mysqli->query($qry);
$totalseatermcount=0;
$rec=$row=$res->fetch_assoc();
$totalseatermcount=$rec['count'];


$qry="SELECT SUM(seater) as count FROM hostel WHERE block_type='PDS Halls' and status='Good'";
$res=$mysqli->query($qry);
$pdsseatercount=0;
$rec=$row=$res->fetch_assoc();
$pdsseatercount=$rec['count'];


$qry="SELECT SUM(seater) as count FROM hostel WHERE block_type='New Hostels' and status='Good'";
$res=$mysqli->query($qry);
$nhseatercount=0;
$rec=$row=$res->fetch_assoc();
$nhseatercount=$rec['count'];


$qry="SELECT SUM(seater) as count FROM hostel WHERE block_type='Old Hostels' and status='Good'";
$res=$mysqli->query($qry);
$ohseatercount=0;
$rec=$row=$res->fetch_assoc();
$ohseatercount=$rec['count'];

$result ="SELECT count(hid) FROM bookings";
$stmt =$mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($totaltempcount);
$stmt->fetch();
$stmt->close();
?>