<?php
include('config.php');
$user=$_SESSION['user'];
$result ="SELECT count(*) FROM admin WHERE aemail=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('s',$user);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
if($count<1){
	header("Location: ../index.php");
	exit;
}else{

$aid=$_SESSION['id'];
$ret="select * from admin where id=$aid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$adminemail=$row['aemail'];
$adminfname=$row['afname'];
$adminlname=$row['alname'];
$designation=$row['designation'];
$adminregdate=$row['reg_date'];
}
}
if ($designation=='admin'){
		$designationfull='Super Admin';
	}elseif($designation=='sec'){
		$designationfull='Secretary';
	}else{
		$designationfull='Hostel Manager';
	}
		
$ret="select * from session";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
		  $session=$row->year1.'/'.$row->year2;
		  $sadminsign=$row->signature;
	  }
?>
