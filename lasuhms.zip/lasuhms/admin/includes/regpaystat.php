<?php
include('config.php');

$seater=1;
$result ="SELECT count(*) FROM hostelreg WHERE seater=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$seater);
$stmt->execute();
$stmt->bind_result($seater1count);
$stmt->fetch();
$stmt->close();

$seater=2;
$result ="SELECT count(*) FROM hostelreg WHERE seater=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$seater);
$stmt->execute();
$stmt->bind_result($seater2count);
$stmt->fetch();
$stmt->close();

$seater=3;
$result ="SELECT count(*) FROM hostelreg WHERE seater=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$blocktype);
$stmt->execute();
$stmt->bind_result($seater3count);
$stmt->fetch();
$stmt->close();

$seater=4;
$result ="SELECT count(*) FROM hostelreg WHERE seater=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$seater);
$stmt->execute();
$stmt->bind_result($seater4count);
$stmt->fetch();
$stmt->close();

$blk_typ="  PDS halls";
$totalpds="SELECT sum(fees) as total FROM hostelreg WHERE blocktype=?";
$stmt =$mysqli->prepare($totalpds);
$stmt->bind_param('s',$blk_typ);
$stmt->execute();
$stmt->bind_result($pdssum);
$stmt->fetch();
$stmt->close();


$blk_typ="  New Hostels";
$totalnh="SELECT sum(fees) as total FROM hostelreg WHERE blocktype=$blk_typ";
$stmt =$mysqli->prepare($totalnh);
$stmt->bind_param('s',$blk_typ);
$stmt->execute();
$stmt->bind_result($nhsum);
$stmt->fetch();
$stmt->close();

$blk_typ="  Old Hostels";
$totaloh="SELECT sum(fees) as total FROM hostelreg WHERE blocktype=?";
$stmt =$mysqli->prepare($totaloh);
$stmt->bind_param('s',$blk_typ);
$stmt->execute();
$stmt->bind_result($ohsum);
$stmt->fetch();
$stmt->close();$totaloh="SELECT sum(fees) as total FROM hostelreg WHERE blocktype=$blk_typ";


?>