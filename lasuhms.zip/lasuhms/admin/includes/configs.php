<?php
//error_reporting(0);
$db_connect =mysql_connect("localhost","root","");
mysql_select_db("lasuhostel") or die(mysql_error($db_connect));

?>