		<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
				<div class="user-panel">
					<div class="pull-left image">
					<img src="../img/user.jpg" class="img-circle" alt="User Image">
					</div>
       				<li><a href="#"> &nbsp;<?php echo $adminfname.' '.$adminlname;?></a>
						<ul>
					<li><a href="admin-profile.php">My Account</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
				</li>
   
      </div>
									<?php if($designation=="admin")
					{
					echo '<li class="ts-label">'.$designationfull.' Navigation</li>';
				echo '<li><a href="admin/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>';
					}elseif($designation=="sec")
					{
					echo '<li class="ts-label">'.$designationfull.' Navigation</li>';
				echo '<li><a href="sec/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>';
					}elseif($designation=="hman")
					{
					echo '<li class="ts-label"><center>'.$designationfull.' Navigation</center></li>';
				echo '<li><a href="hman/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>';
					 }else{ 
					echo '<li class="ts-label">Main</li>';
					 }?>
		
</ul>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />

		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>


<style> .foot{color:#fff; text-align: center;}</style>

		</nav>
		