<?php if ($designation!="admin"){
							
							?>
<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main Navigation</li>
</ul>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>

<style> .foot{color:#fff; text-align: center;}</style>
		</nav>
		
		<?php }else{ ?>
		
		<nav class="ts-sidebar">
		
		
		
			<ul class="ts-sidebar-menu">
			
			<div class="user-panel">
        <div class="pull-left image">
          <img src="../../img/user.jpg" class="img-circle" alt="User Image">
        </div>
       
          <li><a href="#"> &nbsp;<?php echo $adminfname.' '.$adminlname;?></a>
				<ul>
					<li><a href="../admin-profile.php">My Account</a></li>
					<li><a href="../logout.php">Logout</a></li>
				</ul>
				</li>
   
      </div>
			
				<li class="ts-label">Main Navigation</li>
				<li><a href="../admin/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<li><a href="../admin/adminsignature.php"><i class="fa fa-gear"></i> Update Session & Signature</a></li>
				<li><a href="../admin/add_opslink.php"><i class="fa fa-gear"></i> Turn on Features</a></li>
				<li><a href="../admin/add_admin.php"><i class="ion ion-person-add"></i> Add Admin</a></li>
				<li><a href="../admin/adminlist.php"><i class="fa fa-users"></i>Manage Admin</a></li>
				<li><a href="../admin/hostel_stat.php"><i class="fa fa-pie-chart"></i>Hostels Statistics</a></li>
				<li><a href="../admin/paymentstat.php"><i class="fa fa-pie-chart"></i>Registration Statistics</a></li>
				<li><a href="../admin/access_log.php"><i class="fa fa-file"></i>User Access logs</a></li>
</ul>
		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>


<style> .foot{color:#fff; text-align: center;}</style>

		</nav>
		<?php } ?>