<?php 
	include"../includes/myaddy.php";
	include('../includes/adminmy.php');
	include('../includes/hostelstat.php');
	include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<?php if($designation!='admin'){
						include '../includes/warning.php';
					}else{
					?>	
					<div class="panel panel-primary">
						<div class="row">
							<div class="col-md-12">
									<div class="panel-body">
								<div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <center><h3 class="box-title"><?php echo $page;?></h3></center>

              <div class="box-tools">
               </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table">
                <tbody><tr>
                  <th style="width: 20px;">#</th>
                  <th>Item </th>
                  <th>No</th>
				  <th>Percentage</th>
                </tr>
				<tr>
				
				<?php if($stucount<1){
					$stucount=1;
				}?>
                  <td>1.</td>
                  <td>Total Students Sign Up</td>
                  <td>
					<?php echo $stucount;?>
				  </td>
				  <?php $alstuper=($stucount/$stucount)*100;?>
				  <td><span class="badge bg-green"><?php echo $alstuper;?>%</span></td>
                </tr>
                <tr>
                  <td>2.</td>
                  <td>Total Registered</td>
                  <td>
                    <?php echo $hregcount;?>
                  </td>
                  <?php $hregper=($hregcount/$stucount)*100;?>
				  <td><span class="badge bg-red"><?php echo $hregper;?>% of registered students</span></td>
                </tr>
                <tr>
                  <td>3.</td>
				  
				<?php if($hregcount<1){
					$hregcount=1;
				}
				if($pdsregcount<1){
					$pdsregcount=1;
				}?>
                  <td>Reg. PDS Students</td>
                  <td> <?php echo $pdsregcount;?>
                  </td>
                 <?php $pdsregper=($pdsregcount/$hregcount)*100;?>
				  <td><span class="badge bg-blue"><?php echo $pdsregper;?>% of registered students</span></td>
                </tr>
                <tr>
                  <td>4.</td>
                  <td>Reg. OtherStudents</td>
                  <td> <?php $allothercount=$nhregcount+$ohregcount;
				  echo $allothercount;?>
                  </td>
                  
				  <?php $allotherper=($allothercount/$hregcount)*100;?>
				  <td><span class="badge bg-green"><?php echo $allotherper;?>% of registered students</span></td>
                </tr>
				<tr>
                  <td>5.</td>
				  
                  <td>Total Amount</td>
                  <td> <?php
				if($totalfees<1){
					$totalfees=1;
				}	
				echo $totalfees;?>
                  </td>
                  <?php $totalper=($totalfees/$totalfees)*100;?>
				  <td><span class="badge bg-green"><?php echo $totalper;?>% of registered students</span></td>
                </tr>
				<tr>
                  <td>6.</td>
                  <td>PDS Total Fees</td>
                  <td> <?php 
				  if($totalpdsfees<1){
					$totalpdsfees=1;
				}	
				  echo $totalpdsfees;?>
                  </td>
				  <?php $tpdsper=($totalpdsfees/$totalfees)*100;?>
				  <td><span class="badge bg-green"><?php echo $tpdsper;?>%</span></td>
                </tr>
				<tr>
                  <td>7.</td>
                  <td>New Hostels Total Fees</td>
                  <td> <?php echo $totalnhfees;?>
                  </td>
				  <?php $tnhper=($totalnhfees/$totalfees)*100;?>
				  <td><span class="badge bg-green"><?php echo $tnhper;?>%</span></td>
                </tr>
				<tr>
                  <td>8.</td>
                  <td>Old Hostels Total Fees</td>
                  <td> <?php echo $totalohfees;?>
                  </td>
				  <?php $tohper=($totalohfees/$totalfees)*100;?>
				  <td><span class="badge bg-green"><?php echo $tohper;?>%</span></td>
                </tr>
				</tbody></table>
            </div>
            <!-- /.box-body -->
             </div>
		 </div>
<!--  Main Page-->
										
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
					<?php } ?>
	</div>
	</div>