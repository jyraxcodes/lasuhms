	<?php
include"../includes/myaddy.php";
include"../includes/adminmy.php";
include"../../includes/add_opslink.php";
include"../includes/header.php";
?>
	
	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">
					
							
				<div class="row">
					<div class="col-md-12">
						<?php if ($designation!="admin"){
							include "../includes/warning.php";
							}else{ ?>
					
					<div class="panel panel-primary">
					<center><h2 class="page-title">Turn ON/OFF An Operational Link</h2></center>

						<div class="row">
							<div class="col-md-12">

									<div class="panel-body">
<table width="100%" border="0">
<tr>
<th>Operation Links</th><th>Status</th><th>Option</th></tr>
<tr>									<form method="post" class="form-horizontal">
<td><b> Students Registration</b></td>			
<td>Current Status:&nbsp;&nbsp;<b><?php echo $studentregstatus;?></b></td>
<input type="hidden" name="studregstat" value="<?php echo $studentregstatus;?>" />
<td><input class="btn btn-primary" type="submit" name="submit1" value="Change Status"></td>
												
										</form>
</tr>
<tr>								<form method="post" class="form-horizontal">
<td><b> Prebook Session	</b>		</td>
<td>Current Status:&nbsp;&nbsp;<b><?php echo $prebookstatus;?></b></td>
<input type="hidden" name="prebookstat" value="<?php echo $prebookstatus;?>" />
<td><input class="btn btn-primary" type="submit" name="submit2" value="Change Status"></td>
											
											</form>
</tr>
<tr>								<form method="post" class="form-horizontal">
<td><b> Booking and Hostel Reg Session	</b></td>		
<td>Current Status:&nbsp;&nbsp;<b><?php echo $bookstatus;?></b></td>
<input type="hidden" name="bookinstat" value="<?php echo $bookstatus;?>" />
<td><input class="btn btn-primary" type="submit" name="submit3" value="Change Status"></td>
												
										</form>
										</tr></table>
							</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
							<?php } ?>
	</div></div>
	