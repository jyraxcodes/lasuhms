
<?php

include"../includes/myaddy.php";
include"../includes/adminmy.php";
include"../../includes/add_opslink.php";
include"../includes/header.php";
//
if(isset($_GET['del']))
{
	$id=intval($_GET['del']);
	$adn="delete from admin where id=?";
		$stmt= $mysqli->prepare($adn);
		$stmt->bind_param('i',$id);
        $stmt->execute(); 
        echo "<script>alert('Hostel Deleted');</script>" ;
		
        $stmt->close();	  
}
?>
		<?php include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					
						<?php if($designation!='admin'){
						include '../includes/warning.php';
					}else{
					?>	
					<div class="panel panel-primary">

						<div class="row">
							<div class="col-md-12">
							
								
									<div class="panel-body">
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sno.</th>
										
											<th>First Name.</th>
											<th>Last Name</th>
											<th>Email Address</th>
											<th>Designation</th>
											<th>Delete</th>
										</tr>
									</thead>
									<tfoot>
										<tr>
											<th>Sno.</th>
										
											<th>First Name.</th>
											<th>Last Name</th>
											<th>Email Address</th>
											<th>Designation</th>
											<th>Delete</th>
										</tr>
									</tfoot>
									<tbody>
<?php	
$ret="select * from admin";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $row->afname;?></td>
<td><?php echo $row->alname;?></td>
<td><?php echo $row->aemail;?></td>
<td><?php echo $row->designation;?></td>
<td><a href="adminlist.php?del=<?php echo $row->id;?>" onclick="return confirm('Do you want to delete');"><i class="fa fa-close"></i></a></td>
										</tr>
									<?php
$cnt=$cnt+1;
					} ?>
											
										
									</tbody>
								</table>
<!--  Main Page-->
					
										
								</div>
							</div>
						</div>
						<?php 
						} ?>
					</div>
				</div> 	
			</div>
		</div>
	</div>
	</div>