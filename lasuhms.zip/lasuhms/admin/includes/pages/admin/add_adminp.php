
	<?php	
	include"../includes/myaddy.php";
	include"../../includes/add_admin.php";
	include("../includes/headers.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
					<div class="panel panel-primary">
					<center><h2 class="page-title">Add An Admin</h2></center>

						<div class="row">
							<div class="col-md-12">
						<?php if($designation!='admin'){
						include '../includes/warning.php';
					}else{
					?>									
									<div class="panel-body">
									<form method="post" action="add_admin.php" class="form-horizontal">
									
							<!--  Main Page-->
<div class="form-group">
<label class="col-sm-3 control-label">Admin First Name</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="afname" id="afname" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Admin Last Name</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="alname" id="alname" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Admin Email</label>
<div class="col-sm-4">
<input type="email" class="form-control" name="aemail" id="aemail" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Password</label>
<div class="col-sm-4">
<input type="password" class="form-control" name="apass" id="apass" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Select Designation</label>
<div class="col-sm-4">
<select name="adesignation" id="adesignation" class="form-control" required="required">
<option value="">Select Designation</option>
<option value="admin">Admin</option>
<option value="hman">Hostel Manager</option>
<option value="sec">Secretary</option>
</select>
</div>
</div>

<div class="col-sm-8 col-sm-offset-4">
<input class="btn btn-primary" type="submit" name="submit" value="Add Admin ">
												</div>
											</div>

										</form>
										
								</div>
							<?php } ?>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>