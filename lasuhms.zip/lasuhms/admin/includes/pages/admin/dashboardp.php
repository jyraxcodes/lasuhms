<?php 
	include('../includes/myaddy.php');
	include('../includes/adminmy.php');
	include('../includes/hostelstat.php');
	include('../includes/header.php');?>

	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">


					<?php if($designation!='admin'){
						echo "You are not authorised to view this page";
					}else{
					?>
										
	<div class="row">
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $admincount;?></h3>

              <p>All Admins</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $prebookstatus;?></h3>

              <p>Prebooking Hostel</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $bookstatus;?></h3>

              <p>Booking Hostel & Registration</p>
            </div>
            <div class="icon">
              <i class="fa fa-list"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
				<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $studentregstatus;?></h3>

              <p>Students Registration</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
			
									

								</div>
								
										
								<!----------------------End of Third Row----------------------------------->				
				<div class="row">
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $hostelcount;?></h3>

              <p>Total Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-institution"></i>
            </div>
            <a href="manage_hotel.php" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-olive">
            <div class="inner">
              <h3><?php echo $gcount;?></h3>

              <p>Good Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp; 
            </a>
          </div>
        </div>
									
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $dcount;?></h3>

              <p>Damaged Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp;
            </a>
          </div>
        </div>
									
										
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3><?php echo $ocount;?></h3>

              <p>Official Used Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp;
            </a>
          </div>
        </div>
									
									

								</div>
								
				<!----------------------End of First Row----------------------------------->

		<div class="row">
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $stucount;?></h3>

              <p>Total Students Registered</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="userreglist.php" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-olive">
            <div class="inner">
              <h3><?php echo $hregcount;?></h3>

              <p>Payment Confirmed</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="registrationlist.php" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
									
		<div class="col-lg-5 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3>N<?php echo $totalfees;?></h3>

              <p>Total Cash</p>
            </div>
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp;
            </a>
          </div>
        </div>
									
									

								</div>
								
				<!----------------------End of First Row----------------------------------->	
								
	<div class="row">
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $totalseatercount;?></h3>

              <p>Total Hostel Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $pdsseatercount;?></h3>

              <p>Seaters PDS Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $ohseatercount;?></h3>

              <p>Seaters Old Hostels</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
				<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $nhseatercount;?></h3>

              <p>Seaters New Hostels</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
			
									

								</div>
								
								<!----------------------End of Third Row----------------------------------->				

					</div>
				</div>
					<?php } ?>
			</div>
		</div>
	</div>
