<?php include"../includes/myaddy.php";

if(isset($_POST['Save']))
{ 
 
 if($_FILES["profile_pic"]["name"]!='')
  {
   
$target_dir="students/";
$imgname=$_FILES["profile_pic"]["name"];
$type = $_FILES["profile_pic"]["type"];
$size = $_FILES["profile_pic"]["size"];

$temp = $_FILES["profile_pic"]["tmp_name"]; 
$error = $_FILES["profile_pic"]["error"];//size
  if($error>0)
  {
    die("Error uploading file! Code $error.");
  }
  else
  { 
    if ($type=="images/" || $size > 500000)
    {
		echo $size;
      die("that format is not allowed or file size is too big!");
    }
    else
    { //echo "string"; exit;
     move_uploaded_file($temp,"../../img/".$imgname); 
     // echo"Upload Complete";  
    }
  }
    } 
    else
    {
      
    }
	
$year1=$_POST['year1'];
$year2=$_POST['year2'];

$query="INSERT INTO session year1,year2,signature) VALUES(?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('sss',$year1,$year2,$imgname);
$stmt->execute();
echo"<script>alert('Signature and Session updated Succssfully');</script>";
}?>
<?php include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<?php if($designation!='admin'){
						include '../includes/warning.php';
					}else{
					?>	
					<div class="panel panel-primary">
					<center><h2 class="page-title"><?php echo $page;?></h2></center>

						<div class="row">
							<div class="col-md-12">
								
									<div class="panel-body">
									<form method="post" class="form-horizontal" enctype="multipart/form-data" >
									

							<!--  Main Page-->

<div class="form-group">
<label class="col-sm-3 control-label">Signature</label>
<div class="col-sm-4">
<input type="file" name="profile_pic" >
<span><i> Picture size should be 252px by 39px:</i></span>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Year 1</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="year1" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Year 2</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="year2"  required="required">
</div>
</div>

<div class="form-group">
         <div class="col-sm-3"></div><div class="col-sm-2">  <button type="submit"  name="Save" class="btn btn-success bg-green" ><i class="fa fa-file-text"></i> Save</button></div>
          <div class="col-sm-2"> <button type="reset"  name="reset" class="btn btn-primary" value="reset"><i class="f fa fa-undo"></i> Reset</button></div>
          </div>
		            </form>

		  
<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sno.</th>
										
											<th>Session</th>
											<th>Signature</th>
											<th>Delete</th>
										</tr>
									</thead>
									<tfoot>
										<tr>
											<th>Sno.</th>
										
											<th>Session</th>
											<th>Signature</th>
											<th>Delete</th>
										</tr>
									</tfoot>
									<tbody>
<?php	
$ret="select * from session";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $session;?></td>
<td><img src="../../img/<?php echo $sadminsign;?>"</td>
<td><a href="adminsignature.php?del=<?php echo $row->session_id;?>" onclick="return confirm('Do you want to delete');"><i class="fa fa-close"></i></a></td>
										</tr>
									<?php
$cnt=$cnt+1;
					} ?>
							<?php } ?>
							
							
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>


