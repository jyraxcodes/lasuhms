<?php 
include"../includes/myaddy.php";
include"../../includes/add_hostel.php";
	include ("../includes/header.php");
	?>
	<div class="ts-main-content">
		<?php 
	include ("../includes/sidebarhman.php");
	?>
<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					<div class="panel panel-primary">

					<center><h2 class="page-title">Add A Hostel</h2></center>

						<div class="row">
							<div class="col-md-12">
					<?php if($designation!='hman'){
						include '../includes/warning.php';
					}else{
					?>

									<div class="panel-body">
									<form method="post" action="add_hostel.php" class="form-horizontal">
									
									<!--  Main Page-->
<div class="form-group">
<label class="col-sm-3 control-label">Hostel Address</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="hosteladd" id="hosteladd" onchange="checkAvailability()" required="required">

<i> Ex. To add Hostel Block 4 Flat 3 Room 1 Enter 040301 as Hostel Address.</i>
<span id="room-availability-status" style="font-size:12px;"></span>

</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Block Number</label>
<div class="col-sm-4">
<select name="blockno" id="blockno" class="form-control">';
					<?php echo '<option>Block Number</option>';
					for($i =1 ; $i <= 70; $i++){
					echo "<option value='$i'>$i</option>";
					} 
					echo '</select>';
					?>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Flat Number </label>
<div class="col-sm-4">
<select name="flatno" id="flatno" class="form-control">';
					<?php echo '<option>Flat no Number</option>';
					for($i =1 ; $i <= 12; $i++){
					echo "<option value='$i'>$i</option>";
					} 
					echo '</select>';
					?>				
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Room No </label>
<div class="col-sm-4">
<select name="roomno" id="roomno" class="form-control">';
					<?php echo '<option value="Not Applicable">Not Applicable</option>';
					for($i =1 ; $i <= 2; $i++){
					echo "<option value='$i'>$i</option>";
					} 
					echo '</select>';
					?>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Block Type  </label>
<div class="col-sm-4"><select name="block_type" id="block_type" class="form-control" required>
<option value="">Select Block Type</option>
<option value="PDS Halls">PDS Halls</option>
<option value="New Hostels">New Hostels</option>
<option value="Old Hostels">Old Hostels</option>
</select>
</div>
</div>


<div class="form-group">
<label class="col-sm-3 control-label">Gender</label>
<div class="col-sm-4"><select name="sex" class="form-control" required>
<option value="">Select Gender</option>
<option value="Female">Female</option>
<option value="Male">Male</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Status </label>
<div class="col-sm-4"><select name="status" class="form-control" required>
<option value="">Select Status</option>
<option value="Official">Official Use</option>
<option value="Damaged">Damaged</option>
<option value="Good">Good</option>
</select>
</div>
</div>



<div class="col-sm-8 col-sm-offset-4">
<input class="btn btn-primary" type="submit" name="submit" value="Create Flat/Room ">
												</div>
											</div>

										</form>
										
								</div>
							</div>
						</div>
					</div>
				</div> 
					<?php }?>				
			</div>
		</div>
	</div>