
		<?php 
		
include"../includes/myaddy.php";
include"../includes/hostelstat.php";
	include ("../includes/header.php");
	?>
	<div class="ts-main-content">
		<?php 
	include ("../includes/sidebarhman.php");
	?>
<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					
					<div class="panel panel-primary">
						<div class="row">
							<div class="col-md-12">
										<?php if($designation!='hman'){
						include '../includes/warning.php';
					}else{
					?>
									<div class="panel-body">
								<div class="col-md-10">
          <div class="box">
            <div class="box-header">
              <center><b><h3 class="box-title"><?php echo $page;?></h3></b></center>

              <div class="box-tools">
               </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table">
                <tbody><tr>
                  <th width="10px">#</th>
                  <th>Hostel </th>
                  <th>No</th>
				  <th>Percentage</th>
                </tr>
				<?php $th=$ohcount+ $nhcount+ $pdscount;?>
                <tr>
                  <td>1.</td>
                  <td>Good Hostels</td>
                  <td>
					<?php echo $gcount;?>
				  </td>
				  <?php $gper=($gcount/$th)*100;?>
				  <td><span class="badge bg-green"><?php echo $gper;?>%</span></td>
                </tr>
                <tr>
                  <td>2.</td>
                  <td>Damaged Hostels</td>
                  <td>
                    <?php echo $dcount;?>
                  </td>
                  <?php $dper=($dcount/$th)*100;?>
				  <td><span class="badge bg-red"><?php echo $dper;?>%</span></td>
                </tr>
                <tr>
                  <td>3.</td>
                  <td>Official Use</td>
                  <td> <?php echo $ocount;?>
                  </td>
                 <?php $oper=($ocount/$th)*100;?>
				  <td><span class="badge bg-blue"><?php echo $oper;?>%</span></td>
                </tr>
                <tr>
                  <td>4.</td>
                  <td>PDS Halls</td>
                  <td> <?php echo $pdscount;?>
                  </td>
                  
				  <?php $pdsper=($pdscount/$th)*100;?>
				  <td><span class="badge bg-green"><?php echo $pdsper;?>%</span></td>
                </tr>
				<tr>
                  <td>5.</td>
                  <td>New Hostels</td>
                  <td> <?php echo $nhcount;?>
                  </td>
                  <?php $nhper=($nhcount/$th)*100;?>
				  <td><span class="badge bg-green"><?php echo $nhper;?>%</span></td>
                </tr>
				<tr>
                  <td>6.</td>
                  <td>Old Hostels Rooms</td>
                  <td> <?php echo $ohcount;?>
                  </td>
				  <?php $ohrper=($ohcount/$th)*100;?>
				  <td><span class="badge bg-green"><?php echo $ohrper;?>%</span></td>
                </tr>
				<tr>
                  <td></td>
                  <td>TOTAL</td>
                  <td> <?php echo $th;?>
                  </td>
                <?php $thper=($th/$th)*100;?>
				  <td><span class="badge bg-green"><?php echo $thper;?>%</span></td>
                </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
		 </div>
<!--  Main Page-->
										
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
					<?php 	} ?>
	</div>
	</div>
