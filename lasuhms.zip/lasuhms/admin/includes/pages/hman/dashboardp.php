<?php include"../includes/myaddy.php";
include('../includes/hostelstat.php');
 
include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebarhman.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					<?php if($designation!='hman'){
						include '../includes/warning.php';
					}else{
					?>

		<div class="row">
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $hostelcount;?></h3>

              <p>Total Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-institution"></i>
            </div>
            <a href="manage_hostel.php" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-olive">
            <div class="inner">
              <h3><?php echo $gcount;?></h3>

              <p>Good Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp; 
            </a>
          </div>
        </div>
									
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $dcount;?></h3>

              <p>Damaged Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp;
            </a>
          </div>
        </div>
									
										
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3><?php echo $ocount;?></h3>

              <p>Official Used Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp;
            </a>
          </div>
        </div>
									
									

								</div>
								
				<!----------------------End of First Row----------------------------------->				
	<div class="row">
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $pdscount;?></h3>

              <p>PDS Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
            </a>
          </div>
        </div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $nhcount;?></h3>

              <p>New Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
            </a>
          </div>
        </div>
				<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $ohcount;?></h3>

              <p>Old Hostels</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="#" class="small-box-footer">
            </a>
          </div>
        </div>
									
			
									

								</div>			
<!----------------------End of Second Row----------------------------------->												
								
	<div class="row">
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $totalseatercount;?></h3>

              <p>Total Hostel Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3><?php echo $totalseaterfmcount;?></h3>

              <p>Female Hostel Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3><?php echo $totalseatermcount;?></h3>

              <p>Male Hostels Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		</div>
								
								<!----------------------End of Third Row----------------------------------->				
	
		<div class="row">
				<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $pdsseatercount;?></h3>

              <p>PDS Hostels Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $ohseatercount;?></h3>

              <p>Old Hostels Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
				<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3><?php echo $nhseatercount;?></h3>

              <p>New Hostels Spaces</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
			
									

								</div>

	
										
								<!----------------------End of Fourth Row----------------------------------->				
								
								
								
							




					</div>
				</div>
					<?php } ?>
			</div>
		</div>
	</div>