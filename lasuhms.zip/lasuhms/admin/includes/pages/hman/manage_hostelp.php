
<?php 
	include"../includes/myaddy.php";
	include ("../includes/header.php");
	?>
	<div class="ts-main-content">
<?php 
	include ("../includes/sidebarhman.php");
	?>
<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
										<?php if($designation!='hman'){
						include '../includes/warning.php';
					}else{
					?>
					<div class="panel panel-primary">
					<center><h2 class="page-title"><?php echo $page;?></h2></center>

						<div class="row">
							<div class="col-md-12">
								
									<div class="panel-body">
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sno.</th>
										
											<th>Hostel Add.</th>
											<th>Block No</th>
											<th>Flat No</th>
											<th>Room No.</th>
											<th>Type</th>
											<th>Group</th>
											<th>Seater</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tfoot>
										<tr>
											<th>Sno.</th>
										
											<th>Hostel Add.</th>
											<th>Block No</th>
											<th>Flat No</th>
											<th>Room No.</th>
											<th>Type</th>
											<th>Group</th>
											<th>Seater</th>
											<th>Status</th>
											<th>Actions</th>
										</tr>
									</tfoot>
									<tbody>
<?php	
$ret="select * from hostel";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $row->hosteladd;?></td>
<td><?php echo $row->blockno;?></td>
<td><?php echo $row->flatno;?></td>
<td><?php echo $row->roomno;?></td>
<td><?php echo $row->block_type;?></td>
<td><?php echo $row->sex;?></td>
<td><?php echo $row->seater;?></td>
<td><?php echo $row->status;?></td>
<td><a href="edit_hostel.php?id=<?php echo $row->id;?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
<a href="manage_hostel.php?del=<?php echo $row->id;?>" onclick="return confirm("Do you want to delete");"><i class="fa fa-close"></i></a></td>
										</tr>
									<?php
$cnt=$cnt+1;
									 } ?>
											
										
									</tbody>
								</table>
<!--  Main Page-->
										
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
				</div> 	
			</div>
		</div>
	</div>
	</div>
