<?php 
	include"../includes/myaddy.php";
	include"../../includes/confirmed.php";
	include ("../includes/header.php");
	?>
	<div class="ts-main-content">
		<?php include("../includes/sidebarsec.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
														
				<?php if($designation!='sec'){
						include '../includes/warning.php';
					}else{
					?>	
					<div class="panel panel-primary">
					<center><h2 class="page-title"><?php echo $page;?></h2></center>

						<div class="row">
							<div class="col-md-12">
								
									<div class="panel-body">
									<form method="post" class="form-horizontal">
								<!--  Main Page-->									
<div class="form-group">
<label class="col-sm-3 control-label">Hostel ID</label>
<div class="col-sm-6">
<input type="text"  onChange="getCDetails(this.value);"  name="hid"  class="form-control"> 
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Hostel Address</label>
<div class="col-sm-6">
<input type="text"   name="hosteladd"  id="hosteladd" class="form-control" disabled> 
<span id="room-availability-status" style="font-size:12px;"></span>
</div>
<div class="col-sm-2">
<button type="button" class="btn btn-block btn-info btn-sm" Onclick="checkAvailability()">Check</button>
</div>
</div>
																								
<div class='form-group'>
<label class='col-sm-3 control-label'>Block Type : </label>
<div class='col-sm-6'>
<input type='text' name="block_type" id="block_type" class='form-control' disabled>
</div>
</div>

<div class='form-group'>
<label class='col-sm-3 control-label'>Per Flat/Room</label>
<div class='col-sm-6'>
<input type='text' class='form-control' name="seater" id="seater" disabled>
</div>
</div>

<div class='form-group'>
<label class='col-sm-3 control-label'>Amount Paid</label>
<div class='col-sm-6'>
<input type='text' name="fees" id="fees" class='form-control' disabled>
</div>
</div>
					

												<div class="col-sm-8 col-sm-offset-4">
						
													<input class="btn btn-primary" type="submit" name="submit" value="Confirm Payment">
												</div>
</form>
							<?php }?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>

	</div>
