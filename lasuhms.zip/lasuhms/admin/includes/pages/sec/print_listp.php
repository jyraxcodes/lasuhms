<?php 
include('../includes/myaddy.php');
include('../includes/adminmy.php');
include('../includes/hostelstat.php');

?>

<?php include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebarsec.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
	<?php if($designation!='sec'){
						include '../includes/warning.php';
					}else{
					?>	
				<div class="row">
		<div class="row">
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <font size="5"><b>All Registrations<br />&nbsp;</b></font>

              <p>Export to EXCEL</p>
            </div>
            <div class="icon">
              <i class="fa fa-file-excel-o"></i>
            </div>
            <a href="../includes/allexcel.php" class="small-box-footer">
              Click to Download <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <font size="5"><b>PDS Payments<br />&nbsp;</b></font>

              <p>Export to EXCEL </p>
            </div>
            <div class="icon">
              <i class="fa fa-file-excel-o"></i>
            </div>
            <a href="../includes/allpdsexcel.php" class="small-box-footer">
             Click to Download <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <font size="5"><b>New Hostels Payments</b></font>

              <p>Export to EXCEL</p>
            </div>
            <div class="icon">
              <i class="fa fa-file-excel-o"></i>
            </div>
            <a href="../includes/allnhexcel.php" class="small-box-footer">
              Click to Download<i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
										
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <font size="5"><b>Old Hostels Payments</b></font>

              <p>Export to EXCEL</p>
            </div>
            <div class="icon">
              <i class="fa fa-file-excel-o"></i>
            </div>
            <a href="../includes/allohexcel.php" class="small-box-footer">
              Click to Download<i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
									

								</div>
					<?php }?>
				<!----------------------End of First Row----------------------------------->				
					</div>
				</div>

			</div>
		</div>
	</div>