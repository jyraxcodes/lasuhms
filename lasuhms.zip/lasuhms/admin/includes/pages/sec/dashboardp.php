
<?php 
include('../includes/myaddy.php');
include('../includes/adminmy.php');
include('../includes/hostelstat.php');
?>
<?php include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebarsec.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">
									
	
	<div class="col-md-12">
		<div class="row">
			<?php if($designation!='sec'){
						include '../includes/warning.php';
					}else{
					?>	
				<div class="row">
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $stucount;?></h3>

              <p>Total Students Registered</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-olive">
            <div class="inner">
              <h3><?php echo $hregcount;?></h3>

              <p>Payment Confirmed</p>
            </div>
            <div class="icon">
              <i class="fa fa-home"></i>
            </div>
            <a href="registrationlist.php" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
									
									
		<div class="col-lg-5 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3>N<?php echo $totalfees;?></h3>

              <p>Total Cash</p>
            </div>
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <a href="#" class="small-box-footer">
              &nbsp;
            </a>
          </div>
        </div>
									
									

								</div>
								
				<!----------------------End of First Row----------------------------------->				
	<div class="row">
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $pdsregcount;?></h3>

              <p>PDS Hostels Students</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-people"></i>
            </div>
            <a href="#" class="small-box-footer">
            </a>
          </div>
        </div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $nhregcount;?></h3>

              <p>New Hostels Students</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-people"></i>
            </div>
            <a href="#" class="small-box-footer">
            </a>
          </div>
        </div>
				<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-navy">
            <div class="inner">
              <h3><?php echo $ohregcount;?></h3>

              <p>Old Hostels Students</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-people"></i>
            </div>
            <a href="#" class="small-box-footer">
            </a>
          </div>
        </div>
									
			
									

								</div>			
<!----------------------End of Second Row----------------------------------->												
								
	<div class="row">
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $totalseatercount;?></h3>

              <p>Total Hostel Space</p>
            </div>
            <div class="icon">
              <i class="fa fa-th"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $totaltempcount;?></h3>

              <p>Total Booked</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
				<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>N<?php echo $totalpdsfees;?></h3>

              <p>Total PDS Fees</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
			
									

								</div>
								
								<!----------------------End of Third Row----------------------------------->				
										
								
	<div class="row">
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3><?php echo $seater1count;?></h3>

              <p>Registered 1-Seaters</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $seater2count;?></h3>

              <p>Registered 2-Seaters</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
				<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-purple">
            <div class="inner">
              <h3><?php echo $seater3count;?></h3>

              <p>Registered 3-Seaters</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
			
				<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-olive">
            <div class="inner">
              <h3><?php echo $seater4count;?></h3>

              <p>Registered 4-Seaters</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-people"></i>
            </div>
            <a href="#" class="small-box-footer">
			&nbsp;
            </a>
          </div>
        </div>
									
			
									

								</div>
								
								<!----------------------End of Third Row----------------------------------->				
										
								<!----------------------End of Third Row----------------------------------->				
								
								
								
							



					<?php } ?>
					</div>
				</div>

			</div>
		</div>
	</div>

