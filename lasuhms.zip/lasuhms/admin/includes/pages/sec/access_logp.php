<?php 
	include"../includes/myaddy.php";
	include('../includes/adminmy.php');
	include('../includes/hostelstat.php');
	include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebarsec.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
				<?php if($designation!='sec'){
						include '../includes/warning.php';
					}else{
					?>
					<div class="panel panel-primary">
						<div class="row">
							<div class="col-md-12">

									<div class="panel-body">
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sno.</th>
											<th>User Id</th>
											<th>User Email</th>
											<th>IP</th>
											<th>City</th>
											<th>Country</th>
											<th>Login Time</th>
										</tr>
									</thead>
									<tfoot>
										<tr>
											<th>Sno.</th>
											<th>User Id</th>
											<th>User Email</th>
											<th>IP</th>
											<th>City</th>
											<th>Country</th>
											<th>Login Time</th>
										</tr>
									</tfoot>
									<tbody>
<?php	
$aid=$_SESSION['id'];
$ret="select * from adminlog";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $row->userId;?></td>
<td><?php echo $row->userEmail;?></td>
<td><?php echo $row->userIp;?></td>
<td><?php echo $row->city;?></td>
<td><?php echo $row->country;?></td>
<td><?php echo $row->loginTime;?></td>
										</tr>
									<?php
$cnt=$cnt+1;
									 } ?>
											
										
									</tbody>
								</table>
<!--  Main Page-->
										
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
				</div> 	
			</div>
		</div>
	</div>
	</div>