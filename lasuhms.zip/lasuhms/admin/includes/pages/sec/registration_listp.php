
<?php 
include('../includes/myaddy.php');
include('../includes/adminmy.php');
include('../includes/hostelstat.php');
include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebarsec.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">

			
				<div class="row">
					<div class="col-md-12">
	<?php if($designation!='sec'){
						include '../includes/warning.php';
					}else{
					?>	
				<div class="row">
					<div class="panel panel-primary">
					<center><h2 class="page-title"><?php echo $page;?></h2></center>

						<div class="row">
							<div class="col-md-12">
								
									<div class="panel-body">
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sno.</th>
										
											<th>Hostel ID.</th>
											<th>Hosteladd</th>
											<th>Type</th>
											<th>Fees</th>
											<th>Seater</th>
											<th>Action</th>
										</tr>
									</thead>
									<tfoot>
										<tr>
											<th>Sno.</th>
										
											<th>Hostel ID.</th>
											<th>Hosteladd</th>
											<th>Type</th>
											<th>Fees</th>
											<th>Seater</th>
											<th>Action</th>
										</tr>
									</tfoot>
									<tbody>
<?php	
$ret="select * from hostelreg";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $row->hid;?></td>
<td><?php echo $row->hosteladd;?></td>
<td><?php echo $row->block_type;?></td>
<td><?php echo $row->fees;?></td>
<td><?php echo $row->seater;?></td>
<td><a href="registrationlist.php?del=<?php echo $row->id;?>" onclick="return confirm('Do you want to delete');"><i class="fa fa-close"></i></a></td>
										</tr>
									<?php
$cnt=$cnt+1;
									 } ?>
											
										
									</tbody>
								</table>
<!--  Main Page-->
										
								</div>
							</div>
						</div>
					</div>
					<?php }?>
				</div> 	
			</div>
		</div>
	</div>
	</div>