<?php if ($designation!="hman"){
							
							?>
<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main Navigation</li>
</ul>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>

<style> .foot{color:#fff; text-align: center;}</style>
		</nav>
		
		<?php }else{ ?>
		
		<nav class="ts-sidebar">
		
		
		
			<ul class="ts-sidebar-menu">
			
			<div class="user-panel">
        <div class="pull-left image">
          <img src="../../img/user.jpg" class="img-circle" alt="User Image">
        </div>
       
          <li><a href="#"> &nbsp;<?php echo $adminfname.' '.$adminlname;?></a>
				<ul>
					<li><a href="../admin-profile.php">My Account</a></li>
					<li><a href="../logout.php">Logout</a></li>
				</ul>
				</li>
   
      </div>

				<li class="ts-label">Main Navigation</li>
				<li><a href="../hman/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<li><a href="../hman/add_hostel.php"><i class="fa fa-home"></i>Add New Hostels</a></li>
				<li><a href="../hman/manage_hostel.php"><i class="fa fa-institution"></i>Manage Hostels</a></li>
				<li><a href="../hman/hostel_stat.php"><i class="fa fa-pie-chart"></i>Hostel Statistics</a></li>				
				<li><a href="../hman/accesslog.php"><i class="fa fa-file"></i>Access logs</a></li>
		
</ul>
<br />
<br />
<br />
<br />
<br />
<br />

		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>


<style> .foot{color:#fff; text-align: center;}</style>

		</nav>
		<?php } ?>