<?php
session_start();
include"../../includes/config.php";
include"../includes/checklogin.php";
$page="Administrators List";
?>
<?php include('../includes/head.php');?>
<body>

<?php include("../includes/fatalerroradmin.php");
?>
<?php include("../includes/javascripts.php");
?>

</body>
</html>
