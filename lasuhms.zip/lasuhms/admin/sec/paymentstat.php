<?php
session_start();
include('../includes/config.php');
include('../includes/myaddy.php');
include('../includes/adminmy.php');
include('../includes/hostelstat.php');
$page="Payment Statistics";
?><?php include('../includes/head.php');?>
<body>

<?php include("../includes/fatalerrorsec.php");
?>
<?php include("../includes/javascripts.php");
?>