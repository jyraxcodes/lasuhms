<?php
session_start();
include"../includes/config.php";
include"../includes/checklogin.php";
$page="Printing List";

?>
<?php include('../includes/head.php');?>
<body>

<?php include("../includes/fatalerrorsec.php");
?>
<?php include("../includes/javascripts.php");
?>
<!-- Additional Java Scripts for the Page -->
