<?php
session_start();
include"../includes/config.php";
include"../includes/checklogin.php";
$page="DashBoard";
?>
<?php include('../includes/head.php');?>
<body>

<?php include("../includes/fatalerrorhman.php");
?>
<?php include("../includes/javascripts.php");
?>

</body>
</html>
