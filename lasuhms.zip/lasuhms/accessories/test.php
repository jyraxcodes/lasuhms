<?
session_start();
?>
<form action="test2.php" method="POST">
<?php $D= mt_rand(100000,999999);
	?>
<div class="form-group">
<label class="col-sm-2 control-label">Hostel ID</label>
<div class="col-sm-4">
<input type="hidden" value="<?php echo "$D"; ?>" name="hid" id="hid"  class="form-control" >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Image</label>
<div class="col-sm-4">
<input type="file" name="image" width="70%" >
</div>
</div>
<input type="submit" name="submit" value="submit">
</form>