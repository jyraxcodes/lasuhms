<?php $D= mt_rand(100000,999999);
	?>
<div class="form-group">
<label class="col-sm-3 control-label">Hostel Identity No</label>
<div class="col-sm-4">
<input type="button" value="<?php echo "$D"; ?>" name="hid" id="hid"  class="form-control" Disabled>
</div>
</div>
