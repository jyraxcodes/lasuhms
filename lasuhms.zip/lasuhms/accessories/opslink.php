<?php
session_start();
include"../../includes/config.php";
include"../includes/checklogin.php";
include"../includes/myaddy.php";
include"../includes/adminmy.php";
include"../../includes/add_opslink.php";

?>
<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title> Add Operational Links :: Lagos State University Hostels</title>
	<link rel="stylesheet" href="../../css/font-awesome.min.css">
	<link rel="stylesheet" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" href="../../css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="../../css/bootstrap-social.css">
	<link rel="stylesheet" href="../../css/bootstrap-select.css">
	<link rel="stylesheet" href="../../css/fileinput.min.css">
	<link rel="stylesheet" href="../../css/ionicons/css/ionicons.min.css">
	<link rel="stylesheet" href="../../css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="../../css/style.css">


</head>

<body>
<?php include("../includes/header.php");?>

	<div class="ts-main-content">
		<?php include("../includes/sidebaradmin.php");?>
			<div class="content-wrapper">
			<div class="container-fluid">
					
							<?php if ($designation!="admin"){
							echo 'You are not authorised to view this page';
							}else{ ?>
				<div class="row">
					<div class="col-md-12">
					
					<div class="panel panel-primary">
					<center><h2 class="page-title">Turn ON/OFF An Operational Link</h2></center>

						<div class="row">
							<div class="col-md-12">
								
									<div class="panel-body">
<table width="100%" border="0">
<tr>
<th>Operation Links</th><th>Status</th><th>Option</th></tr>
<tr>									<form method="post" class="form-horizontal">
<td><b> Students Registration</b></td>			
<td>Current Status:&nbsp;&nbsp;<b><?php echo $studentregstatus;?></b></td>
<td><input type="radio" name="studregstat" value="on" /> ON &nbsp;&nbsp; <input type="radio" name="studregstat" value="off" /> OFF</td>
<td><input class="btn btn-primary" type="submit" name="submit1" value="Turn ON/OFF Operational Link"></td>
												
										</form>
</tr>
<tr>								<form method="post" class="form-horizontal">
<td><b> Prebook Session	</b>		</td>
<td>Current Status:&nbsp;&nbsp;<b><?php echo $prebookstatus;?></b></td>
<td><input type="radio" name="prebookstat" value="on" /> ON  &nbsp;&nbsp; <input type="radio" name="prebookstat" value="off" /> OFF </td>
<<td><input class="btn btn-primary" type="submit" name="submit2" value="Turn ON/OFF Operational Link"></td>
											
											</form>
</tr>
<tr>								<form method="post" class="form-horizontal">
<td><b> Booking and Hostel Reg Session	</b></td>		
<td>Current Status:&nbsp;&nbsp;<b><?php echo $bookstatus;?></b></td>
<td><input type="radio" name="bookinstat" value="on" /> ON  &nbsp;&nbsp;<input type="radio" name="bookingstat" value="off" /> OFF</td>
<td><input class="btn btn-primary" type="submit3" name="submit" value="Turn ON/OFF Operational Link"></td>
												
										</form>
										</tr></table>
							</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
							<?php } ?>
	</div></div>
	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap-select.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/dataTables.bootstrap.min.js"></script>
	<script src="../js/Chart.min.js"></script>
	<script src="../js/fileinput.js"></script>
	<script src="../js/chartData.js"></script>
	<script src="../js/main.js"></script>
</body>
<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_addhost.php",
data:'hosteladd='+$("#hosteladd").val(),
type: "POST",
success:function(data){
$("#room-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

<?php include "../../includes/footer.php";?>
</html>