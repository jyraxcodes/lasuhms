<?php
include('config.php');
//code for add hostel
if(isset($_POST['submit1']))
{
	$studregstat=$_POST['studregstat'];
	$prebookstat=$_POST['prebookstat'];
	$bookinstat=$_POST['bookinstat'];
	
if ($studregstat=="on"){
		if(mysqli_query($mysqli,"INSERT INTO  operational_links (operational_code,operational_name,status) VALUES('10001','Students Registration','ON')"));
		echo"<script>alert('Students Registration  has been Turned ON'".$_POST['studregstat'].");</script>";
	}elseif($_POST['studregstat']="off"){
		if(mysqli_query($mysqli,"DELETE FROM operational_links WHERE operational_code ='10001'"));
			echo"<script>alert(' has been Turned OFF ');</script>";
	}else{
	echo"<script>alert('Opslink failed successfully');</script>";
}
}
if(isset($_POST['submit2']))
	
{
if ($prebookstat=="on"){
		if(mysqli_query($mysqli,"INSERT INTO  operational_links(operational_code,operational_name,status) VALUES('10002','Prebooking','ON')"));
			echo"<script>alert('Prebooking  has been Turned ON');</script>";
	}elseif($_POST['studregstat']="off"){
		if(mysqli_query($mysqli,"DELETE FROM operational_links WHERE operational_code ='10002'"));
			echo"<script>alert('Prebooking has been Turned OFF ');</script>";
			}else{
	echo"<script>alert('Prebooking failed successfully');</script>";
}
}
if(isset($_POST['submit3']))
{
if ($bookinstat=="on"){
			if(mysqli_query($mysqli,"INSERT INTO  operational_links (operational_code,operational_name,status) VALUES('10003','Booking','ON')"));
			echo"<script>alert('Booking and Registration have been Turned ON');</script>";
	}elseif($_POST['studregstat']="off"){
		if(mysqli_query($mysqli,"DELETE FROM operational_links WHERE operational_code ='10003'"));
			echo"<script>alert('Booking has been Turned OFF ');</script>";
			}else{
	echo"<script>alert('Booking failed successfully');</script>";
}
}

?>