<?php
session_start();
include"includes/config.php";
include"includes/checklogin.php";
include"includes/my.php";
include"includes/functionprebook.php";
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title> Prebook A Hostel :: Lagos State University Hostels</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script>
function getDetails(val) {
$.ajax({
type: "POST",
url: "includes/get_details.php",
data:'hosteladd1='+val,
success: function(data){
//alert(data);
$('#blockno').val(data);
}
});

$.ajax({
type: "POST",
url: "includes/get_details.php",
data:'hosteladd2='+val,
success: function(data){
//alert(data);
$('#flatno').val(data);
}
});

$.ajax({
type: "POST",
url: "includes/get_details.php",
data:'hosteladd3='+val,
success: function(data){
//alert(data);
$('#roomno').val(data);
}
});

$.ajax({
type: "POST",
url: "includes/get_details.php",
data:'hosteladd4='+val,
success: function(data){
//alert(data);
$('#block_type').val(data);
}
});
$.ajax({
type: "POST",
url: "includes/get_details.php",
data:'hosteladd5='+val,
success: function(data){
//alert(data);
$('#sex').val(data);
}
});
$.ajax({
type: "POST",
url: "includes/get_details.php",
data:'hosteladd6='+val,
success: function(data){
//alert(data);
$('#status').val(data);
}
});
}
</script>
</head>
<body>
<?php 
	include ("includes/header.php");
	?>
	

	<div class="ts-main-content">

	<nav class="ts-sidebar">
		<?php 
	include ("includes/sidebar.php");
	?>
	</nav>
<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					
					<div class="panel panel-primary">
					<center><h2 class="page-title">
						<!-- Page Title-->
					Pre book An Hostel
						</h2></center>

						<div class="row">
							<div class="col-md-12">
								<div class="col-md-12">
									<div class="panel panel-default">
										<div class="panel-heading">
									<!--  Notice-->
									Notice: This doesn't guarrantee you to have your pre booked hostel. This exercise is to help us in preparing Students per hostel.
										</div>
									</div>
									<div class="hr-dashed"></div>
									<div class="panel-body">
									<!--  Main Page-->
<?php 
if ($prebookcount<1){ 
	echo "<span style='color:blue'>Sorry, Prebooking period is over.";
}elseif($bkhosteladd!=""){
	echo "<span style='color:blue'>Sorry, You can only book once. If you have error in your booking, contact the Students Affairs</span>";
}else{?>
									
									
								<form method="post" action="prebook2.php" class="form-horizontal">
											
										
<div class="form-group">
<label class="col-sm-8 control-label"><h4 style="color: green" align="left">Room Related info </h4> </label>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Hostel Add.(eg: 140101)</label>
<div class="col-sm-6">
<input type="text" class="form-control" name="hosteladd" id="hosteladd"  onChange="getDetails(this.value);"  required="required">
<span><i>Please enter your hostel Address without space E.g: For Block 49 Flat 2 Room 1, enter 4921</i></span></br>
<span id="room-availability-status" style="font-size:12px;"></span>
</div>
<input type="button" value="Check Availability" onClick="checkAvailability()">
</div>


<input type="hidden" class="form-control" name="blockno" id="blockno" >

<input type="hidden" class="form-control" name="flatno" id="flatno" >


<input type="hidden" class="form-control" name="roomno" id="roomno" >


<input type="hidden" class="form-control" name="block_type" id="block_type" >


<input type="hidden" class="form-control" name="sex" id="sex">


<input type="hidden" class="form-control" name="status" id="status">





<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit" value="Proceed" class="btn btn-primary">
</div>
</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>
		</div>
<?php }?>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_room.php",
data:'hosteladd='+$("#hosteladd").val(),
type: "POST",
success:function(data){
$("#room-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

<?php include "includes/footer.php";?>
</html>