<?php
session_start();
$_SESSION['hid']=$_POST['hid'];
$_SESSION['image']=$_FILES['image'];

?>
<?php echo $_SESSION['hid'];
	echo $_POST['hid'];
	echo $_SESSION['image'];
	echo $_FILES['image'];
?>