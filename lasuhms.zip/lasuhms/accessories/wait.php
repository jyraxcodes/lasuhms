<?php $aid=$_SESSION['hid'];
$ret="select * from userreg where hid=$aid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$hid=$row["hid"];}
$ret="select * from registration where hid=$hid";
$result=mysqli_query($mysqli,$ret);
while ($rowk=mysqli_fetch_array($result))
{?>

<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Students Personal and Address Information </h4> </label>
</div>	
<div class="form-group">
<label class="col-sm-2 control-label">Date of Birth</label>
<div class="col-sm-4">
<input type="date" value="<?php echo $rowk['dob'];?>" class="form-control" disabled >
<input type="hidden" name="dob" id="dob" value="<?php echo $rowk['dob'];?>" class="form-control" >
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Home Address : </label>
<div class="col-sm-8">
<input type="text" value="<?php echo $rowk['hadd'];?>" class="form-control" disabled></textarea>
<input type="hidden" rows="5" name="hadd"  id="hadd" value="<?php echo $rowk['hadd'];?>" class="form-control" ></textarea>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">City : </label>
<div class="col-sm-4">
<input type="text"value="<?php echo $rowk['hcity'];?>" class="form-control" disabled></textarea>
<input type="hidden" name="hcity"  id="hcity" value="<?php echo $rowk['hcity'];?>" class="form-control" ></textarea>
</div>

<label class="col-sm-2 control-label">State</label>
<div class="col-sm-4">
<input type="text" value="<?php echo $rowk['hstate'];?>" class="form-control" disabled>
<input type="hidden" name="hstate" id="hstate" value="<?php echo $rowk['hstate'];?>" class="form-control" disabled>
</div>
</div>

	<div class="hr-dashed"></div>
<?php if ($row['program']!="PDS"){
	?>


<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Student Education Info</h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Matric No</label>
<div class="col-sm-4">
<input type="text" value="<?php echo $rowk['matricno'];?>" class="form-control" disabled >
<input type="hidden" name="matricno" id="matricno"  value="<?php echo $rowk['matricno'];?>" class="form-control">
</div>

<label class="col-sm-2 control-label">Department</label>
<div class="col-sm-4">
<input type="text"  value="<?php echo $rowk['department'];?>" class="form-control" disabled> 
<input type="hidden" name="dept" id="dept"  value="<?php echo $rowk['department'];?>" class="form-control"> 
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Faculty</label>
<div class="col-sm-4">
<input type="text" value="<?php echo $rowk['faculty'];?>" class="form-control" disabled >
<input type="hidden" name="fac" id="fac"  value="<?php echo $rowk['faculty'];?>" class="form-control" >
</div>
</div>

	<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Parent/Guidian Info </h4> </label>
</div><?php } else {?>
<div class="form-group">
<label class="col-sm-2 control-label"><h4 style="color: blue" align="left">Parent/Guidian Info </h4> </label>
</div>
<?php }?>
<div class="form-group">
<label class="col-sm-2 control-label">Parent/Guardian Name : </label>
<div class="col-sm-4">
<input type="text" value="<?php echo $rowk['gurname'];?>" class="form-control" disabled>
<input type="hidden" name="gurname" id="gurname"  value="<?php echo $rowk['gurname'];?>" class="form-control">
</div>

<label class="col-sm-2 control-label">Relationship : </label>
<div class="col-sm-4">
<input type="text" value="<?php echo $rowk['gurrel'];?>" class="form-control" disabled>
<input type="hidden" name="gurrel" id="gurrel"  value="<?php echo $rowk['gurrel'];?>" class="form-control" >
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Phone Number : </label>
<div class="col-sm-4">
<input type="text" value="<?php echo $rowk['gurphone'];?>" class="form-control" disabled>
<input type="hidden" name="gurphone" id="gurphone"  value="<?php echo $rowk['gurphone'];?>" class="form-control" >
</div>
</div>	


<div class="form-group">
<label class="col-sm-2 control-label">Address : </label>
<div class="col-sm-4">
<textarea  rows="5" value="<?php echo $rowk['guradd'];?>" class="form-control" disabled></textarea>
<textarea type="hidden" rows="5" name="guradd"  id="guradd"  value="<?php echo $rowk['guradd'];?>" class="form-control" ></textarea>
</div>
<label class="col-sm-2 control-label">City : </label>
<div class="col-sm-4">
<textarea  rows="3" value="<?php echo $rowk['gurcity'];?>" class="form-control" disabled></textarea>
<textarea  type="hidden" rows="3" name="gurcity"  id="gurcity"  value="<?php echo $rowk['gurcity'];?>" class="form-control"></textarea>
</div>
<label class="col-sm-2 control-label">State</label>
<div class="col-sm-4">
<input type="text"  value="<?php echo $rowk['gurstate'];?>" class="form-control" disabled>
<input type="text" name="gurstate" id="gurstate"  value="<?php echo $rowk['gurstate'];?>" class="form-control" disabled>
</div>
</div>