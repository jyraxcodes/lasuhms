<?php
 session_start();
include"includes/config.php";
include"includes/checklogin.php";
include"includes/my.php";
include('libs/phpqrcode/qrlib.php'); 

if(isset($_POST['submit']) ) {
	$tempDir = 'temp/'; 
	$filename = "Special";
	$body =  $_POST['msg'];
	$codeContents = '&body='.urlencode($body); 
	QRcode::png($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
}
$page='Allocation Letter';

if (!isset($mylname)){
	include 'includes/failed.php';
}else{
?>
<?php include 'includes/head.php';?>



<?php include 'includes/pages/print_letter.php';?>
<?php include 'includes/javascripts.php';?>
<?php }?>