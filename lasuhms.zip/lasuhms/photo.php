<?php
 session_start();
include"includes/config.php";
include"includes/checklogin.php";
include"includes/my.php";

//session_start();
if(isset($_POST['Save']))
{ 
 
 if($_FILES["profile_pic"]["name"]!='')
  {
   
$target_dir="students/";
$imgname=$_FILES["profile_pic"]["name"];
$type = $_FILES["profile_pic"]["type"];
$size = $_FILES["profile_pic"]["size"];

$temp = $_FILES["profile_pic"]["tmp_name"]; 
$error = $_FILES["profile_pic"]["error"];//size
  if($error>0)
  {
    die("Error uploading file! Code $error.");
  }
  else
  { 
    if ($type=="images/" || $size > 5000000)
    {
      die("that format is not allowed or file size is too big!");
    }
    else
    { //echo "string"; exit;
     move_uploaded_file($temp,"student/".$imgname); 
     // echo"Upload Complete";  
    }
  }
    } 
    else
    {
      
    }

$query="update  registration set imagename=? where hid=?";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('si',$imgname,$myhid);
$stmt->execute();
echo"<script>alert('Profile updated Successfully');</script>";
}
    ?>


<?php include 'includes/head.php';?>
					<center><h2 class="page-title">Update Your Profile Picture</h2></center>
							<div class="col-sm-12">
<form method="POST" enctype="multipart/form-data" >
   <div class="form-group">
<div class="col-sm-4"></div><div class="col-sm-4">
 <?php if ($mypics==""){?>
 <img class="profile-img " name="imageupload" src="img/user.jpg" alt="profile picture" style="height:100px;width:100px;" class="form-control"><?php }else{ 
 echo '<img class="profile-img " name="imageupload"  src="student/'.$mypics.'" alt="profile picture" style="height:100px;width:100px;" class="form-control">'; }?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <input type="file" name="profile_pic" ><span>Profile picture must be 250Kb or less</span>
        </div>   </div>
		<div class="col-sm-6 col-sm-offset-4">
           <button type="submit"  name="Save" class="btn btn-success bg-green" ><i class="fa fa-file-text"></i> Save</button>
           <button type="reset"  name="reset" class="btn btn-primary" value="reset"><i class="f fa fa-undo"></i> Reset</button>
          </div>
			</div>	
				</div>
					</div>
						</div>
					</div>
				</div> 	
<?php include 'includes/javascripts.php';?>
</body>
</html>