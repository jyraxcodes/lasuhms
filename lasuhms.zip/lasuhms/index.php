<?php
 session_start();
include"includes/config.php";
	// it will never let you open index(login) page if session is set
	if ( isset($_SESSION['hid'])!="" ) {
		header("Location: dashboard.php");
		exit;
	}else{
		
include"includes/my.php";
$page="Home";
?>
<?php include 'includes/head.php';?>
<?php include 'includes/pages/index.php';?>
<?php include 'includes/javascripts.php';?>
	<?php }?>
</body>
</html>