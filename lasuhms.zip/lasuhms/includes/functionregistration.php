<?php 
$registrationcount=10001;
$result="SELECT count(*) FROM operational_links WHERE operational_code=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$registrationcount);
$stmt->execute();
$stmt->bind_result($regcount);
$stmt->fetch();
$stmt->close();

?>