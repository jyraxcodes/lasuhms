<?php
include('pdoconfig.php');
if(!empty($_POST["seater"])) 
{	
$id=$_POST['seater'];
if ($id==1){$fee=12000}
else if ($id==2){$fee=6000}
else if ($id==3){$fee=35000}
else{$fee=25000}
?>
 <?php echo htmlentities($fees); ?>
  <?php

}?>
