<?php
//error_reporting(0);
$db_connect =mysqli_connect("localhost","root","");
mysqli_select_db("lasuhostel") or die(mysqli_error($db_connect));

?>