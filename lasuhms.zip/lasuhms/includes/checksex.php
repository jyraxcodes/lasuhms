<?php
include('includes/config.php');
$aid=$_SESSION['hid'];
$ret="select * from userreg where hid=$aid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	echo $sex1=$row['sex'];
}

if(!empty($_POST["sex"])) {
	$sex2= $_POST["sex"];
	if ($sex!=$sex2) {

		echo "error : You can't register opposite sex hostel .";
	}
	else { 
	echo "You can proceed";
}
}
?>