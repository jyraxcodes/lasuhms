<?php
include('config.php');
//code for add admin
if(isset($_POST['submit']))
{
$afname=$_POST['afname'];
$alname=$_POST['alname'];
$aemail=$_POST['aemail'];
$apass=$_POST['apass'];
$adesignation=$_POST['adesignation'];

$query="INSERT INTO  admin (afname,alname,aemail,apassword,designation) VALUES(?,?,?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('sssss',$afname,$alname,$aemail,$apass,$adesignation);
$stmt->execute();
echo"<script>alert('Admin added successfully');</script>";
}

?>