
	<div class="brand clearfix">
		<a href="index.php" class="logo" ><img src="img/logo.gif" height="100%" width="100%"></a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
	</div>