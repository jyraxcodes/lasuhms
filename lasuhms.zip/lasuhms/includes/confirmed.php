<?php

include('../includes/config.php');

if(isset($_POST['submit'])){ 
$aid=$_POST['hid'];
$ret="select * from bookings where hid=$aid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$hid= $row['hid'];
$hosteladd= $row['hosteladd'];
$block_type= $row['block_type'];
$seater=$row['seater'];	
$fees=$row['fees'];
}
$title="Payment Confirmed";
$message="<p>Your Payment of ".$fees." for a ".$hosteladd." (a ".$seater." seater located in the ".$block_type." has been confirmed successfully</p><p>You can proceed with completion of your hostel registration and printing of your Hostel Allocation Letter</p>";

$query="INSERT INTO hostelreg (hid,hosteladd,block_type,seater,fees) VALUES(?,?,?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('issii',$hid,$hosteladd,$block_type,$seater,$fees);
$stmt->execute();

$query2="INSERT INTO notifications (hid,title,message) VALUES(?,?,?)";
$stmt2 = $mysqli->prepare($query2);
$rc2=$stmt2->bind_param('iss',$hid,$title,$message);
$stmt2->execute();
echo"<script>alert('Students Payment has been confirmed successfully');</script>";
}

?>