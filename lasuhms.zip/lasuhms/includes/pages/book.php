								
									<?php 																		
									if ($bookingcount<1){ 
										include('includes/periodover.php');
									}elseif($mydob==""){
										include('includes/incomplete.php');
									}elseif($bkcount>0){
										include('includes/useterms.php');
									}else{					?>
								
						<!-- Page Title-->
					<center><h2 class="page-title">
					<?php echo $page  ?>
						</h2></center>
						<div class="row">
							<div class="col-md-12">	
									<div class="panel panel-default">
										<div class="panel-heading">
									<!--  Notice-->
									Notice: This doesn't guarantee you to have your booked hostel. You have to pay on time to have access to the Hostel.<br />
									<font color="red"><b><?php if(isset($msg)){
												echo $msg;
												echo $gender.'/'.$regsex;
										}else{
										}?>
										</b></font></div>
									</div>
									<div class="hr-dashed"></div>
									<div class="panel-body">
								<!--  Main Page-->
								<form method="post"  class="form-horizontal">
										
										
<div class="form-group">
<label class="col-sm-8 control-label"><h4 style="color: green" align="left">Room Related info </h4> </label>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Hostel Address</label>
<div class="col-sm-6">
<input type="text" class="form-control" name="hosteladd" id="hosteladd"  onChange="getDetails(this.value);" onBlur="checkAvailability()"  required="required">
<span style="font-size:12px;"><i> Ex. To book Hostel Block 4 Flat 3 Room 1 Enter 040301 as Hostel Address.</i></span>
<span id="room-availability-status" style="font-size:12px;"></span>

</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Block Number</label>
<div class="col-sm-4">
<input type="text" class="form-control"  id="blockno"  disabled>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Flat Number </label>
<div class="col-sm-4">
<input type="text" class="form-control"  id="flatno"  disabled>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Room No </label>
<div class="col-sm-4">
<input type="text" class="form-control" id="roomno" onChange="checkBookavailability()" >
</div>
<span id="room-bookavailability-status" style="font-size:12px;"></span>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Block Type</label>
<div class="col-sm-4">
<input type="text" class="form-control" id="block_type"  disabled>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Hostel Condition</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="status" id="status" disabled>
</div>
</div>


<div class="form-group">
<label class="col-sm-3 control-label">Student(s) Per Room </label>
<div class="col-sm-4">
<input type="text" class="form-control" name="seater" id="seater" disabled >
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Fees</label>
<div class="col-sm-4">
<input type="text" class="form-control" name="fees" id="fees" disabled>
</div>
</div>

<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit" value="Submit" class="btn btn-primary">
</div>
</form>
									</div>
									<?php }?>
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>