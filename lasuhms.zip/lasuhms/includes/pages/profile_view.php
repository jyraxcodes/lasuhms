									<div class="panel panel-default">
										<div class="panel-body">
										
									<?php 
if($mydob==""){
include 'includes/incomplete.php';
}else{?>
						<table width="100%" class="table table-bordered " border="0"> 
						<tr>
						<center><font size="5"><b><?php echo $myfname;?> <?php echo $mylname;?> Profile</b></font></center>
						</tr>
						<tr>
							<label class="col-sm-12 control-label"><h4 style="color: blue" align="left"><?php echo $myfname;?> Personal Details and Address Information </h4> </label>
						</tr>
						<tr>
						<td width="25%"><center><font size="3"><b>First Name</b></font><br /><?php echo $myfname;?><br /><br />
												<font size="3"><b>Sex</b></font><br /><?php echo $gender;?><br /><br />
												<font size="3"><b>Phone No</b></font><br /><?php echo $myphone;?></center></td>
						<td width="25%"><center><font size="3"><b>Other Name</b></font><br /><?php echo $myoname;?><br /><br />
												<font size="3"><b>Date of Birth</b></font><br /><?php echo $mydob;?><br /><br />
												<font size="3"><b>Home Address</b></font><br /><?php echo $myhadd;?>, <?php echo $myhcity;?></center></td>
						<td width="25%"><center><font size="3"><b>Last Name</b></font><br /><?php echo $mylname;?><br /><br />
												<font size="3"><b>Email Address</b></font><br /><?php echo $myemail;?><br /><br />
												<font size="3"><b>State</b></font><br /><?php echo $myhstate;?></center></td>
						<td width="25%"><div class="widget-user-image">
			  <?php if ($mypics==""){
                echo '<img class="img-circle" width="150px" alt="User Avatar" src="img/user.jpg">';
              }else{
               echo '<img class="img-rectangle" width="150px" alt="User Avatar" src="student/'.$mypics.'">';
			  }?>
              </div></td>
						</tr>
						
						</table>
						<table width="100%" class="table table-bordered "border="0"> 
						<tr>
						<label class="col-sm-12 control-label"><h4 style="color: blue" align="left">Education Information</h4> </label>
						</tr>
						<tr><?php if ($myprogram!="PDS"){?>
						<td width="10%"><center><font size="3"><b>Program</b></font><br /><?php echo $myprogram;?></center></td>
						<td width="10%"><center><font size="3"><b>Matric No</b></font><br /><?php echo $mymatricno;?></center></td>
						<td width="10%"><center><font size="3"><b>Department</b></font><br /><?php echo $mydept;?></center></td>
						<td width="10%"><center><font size="3"><b>Faculty</b></font><br /><?php echo $myfac;?></center></td>
						<td width="10%"><center><font size="3"><b>Email Address</b></font><br /><?php echo $myemail;?></center></td>
						<?php }else{?>
						<td width="10%"><center><font size="3"><b>Program</b></font><br /><?php echo $myprogram;?></center></td>
						<td width="10%"><center><font size="3"><b>&nbsp;&nbsp;</b></font><br />&nbsp;&nbsp;</center></td>
						<td width="10%"><center><font size="3"><b>&nbsp;&nbsp;</b></font><br />&nbsp;&nbsp;</center></td>
							
						<?php }?>
						</tr>
							</table>
						<table width="100%" class="table table-bordered " border="0"> 
						<tr>
						<label class="col-sm-12 control-label"><h4 style="color: blue" align="left"><?php echo $myfname;?> Guardian Information</h4> </label>
						</tr>
						<tr>
						<td width="25%"><center><font size="3"><b>Full Name</b></font><br /><?php echo $mygurname;?><br /><br />
												<font size="3"><b>Address</b></font><br /><?php echo $myguradd;?></center></td>
						<td width="25%"><center><font size="3"><b>Relationship</b></font><br /><?php echo $mygurrel;?><br /><br />
												<font size="3"><b>City</b></font><br /><?php echo $mygurcity;?></center></td>
						<td width="25%"><center><font size="3"><b>Phone</b></font><br /><?php echo $mygurphone;?><br /><br />
												<font size="3"><b>State</b></font><br /><?php echo $mygurstate;?></center></td>
						</tr>
						</table>
									</div>
<?php }?>
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
