					
					<center><h2 class="page-title"><?php echo $page;?></h2></center>

						<div class="row">
							<div class="col-md-12">
									<div class="panel panel-default">
										
										<div class="panel-heading">
									<!--  Notice-->
									<div class="panel-heading"><?php echo $myfname;?>, Complete your profile to have access to prebooking and booking of Hostel										</div>
									</div>
									<div class="panel-body">
<form method="post" name="registration" class="form-horizontal" ">
									<!--  Main Page-->
<?php 
if($mymatricno!=""){
include('includes/useterms.php');
}else{?>
<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Students Personal and Address Information </h4> </label>
</div>	
<div class="form-group">
<label class="col-sm-2 control-label">Date of Birth</label>
<div class="col-sm-4">
<input type="date" name="dob" id="dob"  class="form-control" >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Permanent Address : </label>
<div class="col-sm-4">
<textarea  rows="5" name="hadd"  id="hadd" class="form-control" required="required"></textarea>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">City : </label>
<div class="col-sm-4">
<textarea rows="3" name="hcity"  id="hcity" class="form-control" required="required"></textarea>
</div>

<label class="col-sm-2 control-label">State</label>
<div class="col-sm-4">
<select name="hstate" id="hstate"class="form-control" required="required">
              <option value="" selected="selected">- Select State-</option>
              <option value="Abuja FCT">Abuja FCT</option>
              <option value="Abia">Abia</option>
              <option value="Adamawa">Adamawa</option>
              <option value="Akwa Ibom">Akwa Ibom</option>
              <option value="Anambra">Anambra</option>
              <option value="Bauchi">Bauchi</option>
              <option value="Bayelsa">Bayelsa</option>
              <option value="Benue">Benue</option>
              <option value="Borno">Borno</option>
              <option value="Cross River">Cross River</option>
              <option value="Delta">Delta</option>
              <option value="Ebonyi">Ebonyi</option>
              <option value="Edo">Edo</option>
              <option value="Ekiti">Ekiti</option>
              <option value="Enugu">Enugu</option>
              <option value="Gombe">Gombe</option>
              <option value="Imo">Imo</option>
              <option value="Jigawa">Jigawa</option>
              <option value="Kaduna">Kaduna</option>
              <option value="Kano">Kano</option>
              <option value="Katsina">Katsina</option>
              <option value="Kebbi">Kebbi</option>
              <option value="Kogi">Kogi</option>
              <option value="Kwara">Kwara</option>
              <option value="Lagos">Lagos</option>
              <option value="Nassarawa">Nassarawa</option>
              <option value="Niger">Niger</option>
              <option value="Ogun">Ogun</option>
              <option value="Ondo">Ondo</option>
              <option value="Osun">Osun</option>
              <option value="Oyo">Oyo</option>
              <option value="Plateau">Plateau</option>
              <option value="Rivers">Rivers</option>
              <option value="Sokoto">Sokoto</option>
              <option value="Taraba">Taraba</option>
              <option value="Yobe">Yobe</option>
              <option value="Zamfara">Zamfara</option>
     <option value="Outside Nigeria">Outside Nigeria</option>
            </select>
</div>
</div>
</div>

	<div class="hr-dashed"></div>
<?php
if ($myprogram !="PDS"){

?>


<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Student Education Info</h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Matric No</label>
<div class="col-sm-4">
<input type="text" name="matricno" id="matricno"  class="form-control" required="required" >
</div>

<label class="col-sm-2 control-label">Department</label>
<div class="col-sm-4">
<select name="dept" id="dept"   onChange="getFac(this.value);" class="form-control" required> 
<option value="">Select Department</option>

<?php $query ="SELECT * FROM department";
$stmt2 = $mysqli->prepare($query);
$stmt2->execute();
$res=$stmt2->get_result();
while($rowd=$res->fetch_object())
{
?>
<option value="<?php echo $rowd->dept;?>"><?php echo $rowd->dept;?></option>
<?php } ?>
</select> </div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Faculty</label>
<div class="col-sm-4">
<input type="text" name="fac" id="fac"  class="form-control" required="required" >
</div>
</div>

	<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Parent/Guidian Info </h4> </label>
</div>
<?php } else {?>
<div class="form-group">
<label class="col-sm-2 control-label"><h4 style="color: blue" align="left">Parent/Guidian Info </h4> </label>
</div>
<?php }?>
<div class="form-group">
<label class="col-sm-2 control-label">Guardian Name : </label>
<div class="col-sm-4">
<input type="text" name="gurname" id="gurname"  class="form-control" required="required">
</div>

<label class="col-sm-2 control-label">Relationship : </label>
<div class="col-sm-4">
<input type="text" name="gurrel" id="gurrel"  class="form-control" required="required">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Phone Number : </label>
<div class="col-sm-4">
<input type="text" name="gurphone" id="gurphone"  class="form-control" required="required">
</div>
</div>	

						
<div class="form-group">
<label class="col-sm-5 control-label">Permanent Address same as Parent/ Guardian Address: </label>
<div class="col-sm-4">
<input type="checkbox" name="adcheck" value="1"/>
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Address : </label>
<div class="col-sm-4">
<textarea  rows="5" name="guradd"  id="guradd" class="form-control" required="required"></textarea>
</div>
<label class="col-sm-2 control-label">City : </label>
<div class="col-sm-4">
<textarea  rows="3" name="gurcity"  id="gurcity" class="form-control" required="required"></textarea>
</div>
<label class="col-sm-2 control-label">State</label>
<div class="col-sm-4">
<select name="gurstate" id="gurstate"class="form-control" required="required">
              <option value="" selected="selected">- Select -</option>
              <option value="Abuja FCT">Abuja FCT</option>
              <option value="Abia">Abia</option>
              <option value="Adamawa">Adamawa</option>
              <option value="Akwa Ibom">Akwa Ibom</option>
              <option value="Anambra">Anambra</option>
              <option value="Bauchi">Bauchi</option>
              <option value="Bayelsa">Bayelsa</option>
              <option value="Benue">Benue</option>
              <option value="Borno">Borno</option>
              <option value="Cross River">Cross River</option>
              <option value="Delta">Delta</option>
              <option value="Ebonyi">Ebonyi</option>
              <option value="Edo">Edo</option>
              <option value="Ekiti">Ekiti</option>
              <option value="Enugu">Enugu</option>
              <option value="Gombe">Gombe</option>
              <option value="Imo">Imo</option>
              <option value="Jigawa">Jigawa</option>
              <option value="Kaduna">Kaduna</option>
              <option value="Kano">Kano</option>
              <option value="Katsina">Katsina</option>
              <option value="Kebbi">Kebbi</option>
              <option value="Kogi">Kogi</option>
              <option value="Kwara">Kwara</option>
              <option value="Lagos">Lagos</option>
              <option value="Nassarawa">Nassarawa</option>
              <option value="Niger">Niger</option>
              <option value="Ogun">Ogun</option>
              <option value="Ondo">Ondo</option>
              <option value="Osun">Osun</option>
              <option value="Oyo">Oyo</option>
              <option value="Plateau">Plateau</option>
              <option value="Rivers">Rivers</option>
              <option value="Sokoto">Sokoto</option>
              <option value="Taraba">Taraba</option>
              <option value="Yobe">Yobe</option>
              <option value="Zamfara">Zamfara</option>
     <option value="Outside Nigeria">Outside Nigeria</option>
            </select>
</div>
</div>
	<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-4 control-label"><h4 style="color: blue" align="left">Clinic Card ID</h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Clinic ID: </label>
<div class="col-sm-8">
<input type="text" name="cid" id="cid"  class="form-control">
</div>
</div>


	<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="save" value="Submit" class="btn btn-primary">
</div>
</form>
<?php }?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>

	</div>
