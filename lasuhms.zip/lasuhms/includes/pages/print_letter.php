						<div class="row">
							<div class="col-md-12">	
								<div class="panel panel-default">
									<div class="panel-body">						
						
						<form method="post" action="letter2.php" >
						<input type="hidden" class="form-control" name="msg" style="width:20em;" value="This is to approve that <?php if ($mysex=="Male"){ echo 'Mr';}else{echo 'Miss';}?> <?php echo ucfirst($myfname);?>  <?php echo ucfirst($myoname);?>  <?php echo ucfirst($mylname);?> with Hostel Identity No 
						<?php echo ucfirst($myhid); ?>and Matric Number<?php echo ucfirst($mymatricno);?> of the <?php echo ucfirst($mydept);?> has been allocated to Block <?php echo ucfirst($myblockno);?>, <?php if ($myblocktype=="Old Hostels"){?>
					Flat <?php echo ucfirst($myflatno);?>, Room <?php echo ucfirst($myroomno);?>.<?php }else{?>
			Flat <?php echo ucfirst($myflatno);}?></p>
			<?php echo ucfirst($myregdate.'/'.$myflatno);?>">
					
			<?php
			if(!isset($filename)){
				$filename = "author";
			}
			?>
	<br /><br /><br />
			<div class="form-group">
				<div class="col-md-4 qrcode">
				<center>
			<input type="submit" name="submit" class="btn submitBtn" value="Print Hostel Allocation" style="width:20em; margin:0;" >
					</center>
										
			</div> </div> 					
			</div> </div> 					
			</div> </div> 
			</form>