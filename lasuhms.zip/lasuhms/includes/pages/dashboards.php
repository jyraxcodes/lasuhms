<?php 
if ($mylname==""){
	include 'includes/failed.php';
}else{
	include('includes/pdoconfig.php');
	include('includes/my.php');
	?>

								<div class="row">
								<div class="col-md-12">
									<div class="col-md-5">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-yellow">
              <div class="widget-user-image">
			  <?php if ($mypics==""){
                echo '<img class="img-circle" alt="User Avatar" src="img/user.jpg">';
              }else{
               echo '<img class="img-circle" alt="User Avatar" src="student/'.$mypics.'">';
			  }?>
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?php echo $myfname;?> <?php echo $mylname;?> (<?php echo $myhid;?>)</h3>
              <b><h4 class="widget-user-desc">Program:<?php echo $myprogram;?></h4></b>
              </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">

                <li><a href="#">Registration Status <span class="pull-right badge bg-blue">
				
			  <?php if ($mydob=="" or $myhadd=="" or $mygurname=="" or $mygurphone=="" or $myguradd==""){
				  echo "Uncompleted";
			  }else{
				  echo "Completed";
			  }
				?>
				</span></a></li>
                <li><a href="#">Booked Hostel <span class="pull-right badge bg-aqua">
				
				  <?php if ($bkhosteladd==""){
				  echo "No Booking";
			  }else{
				  echo $bkblockno.',';
				  if ($bkblocktype=="Old Hostels"){
					  echo$bkflatno.','.$bkroomno;
				  }else{
				  echo $bkflatno;
				  } 
			  }
				?>
				</span></a></li>
                <li><a href="#">Allocated Hostel <span class="pull-right badge bg-green">
				 <?php 
				 if ($myhosteladd==""){
				  echo "Not Allocated";
			  }else{	
					 echo $myhosteladd;			  
			  }
				?>
				</span></a></li>
                <li><a href="#">Allocated Block Type <span class="pull-right badge bg-red">
				<?php if ($myhosteladd==""){
				  echo "Not Allocated";
			  }else{
				  echo $myblocktype;
			  }
				?></span></a></li>
              </ul>
            </div>
          </div>
          <!-- /.widget-user -->
        </div>
		<?php if ($mydob=="" or $myhadd=="" or $mygurphone==""){
			?>
				
		<?php include 'includes/notification.php';?>
          <!-- /.box -->
        </div></div>
		<div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <p>Continue Registration</p>
            </div>
            <div class="icon">
              <i class="glyphicon glyphicon-plus"></i>
            </div>
            <a class="small-box-footer" href="#">
              Continue Here<i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
		<?php 
		}else{?>
		<?php include 'includes/notification.php';?>
        <?php }?>
		 </div> </div>
								<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-primary text-light">
												<div class="stat-panel text-center">



													<div class="stat-panel-number h3 ">View Profile</div>

												</div>
											</div>
											<a href="profile.php" class="block-anchor panel-footer">Full Detail <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-warning text-light">
												<div class="stat-panel text-center">

												<div class="stat-panel-number h3 ">Check Clinic ID</div>

												</div>
											</div>
											<a href="check_cid.php" class="block-anchor panel-footer text-center">Check Now! &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-success text-light">
												<div class="stat-panel text-center">

												<div class="stat-panel-number h3 ">Hostel Records</div>

												</div>
											</div>
											<a href="hostelrecord.php" class="block-anchor panel-footer text-center">See All &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
								
								</div>
							</div>
						</div>

<?php }?>