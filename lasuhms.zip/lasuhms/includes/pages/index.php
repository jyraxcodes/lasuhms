<center><h3 class="page-title">LASU, Epe Campus, Hostel Management and Registration</h3></center>

						<div class="row">
							<div class="col-md-12">
								<div class="panel-body">
									<p>The Hostel Management website was created for easy payments and allocation of hostel fees and hostels respectively. 
									The registration site for students of Lagos State University, Epe Campus.<br>
									Follow the Simple rules to register your hostel with no issue.
									<ol><li>1. Sign up as a new student when the session begins to have your <strong>Hostel Identity Number(HID).</strong></li>
									<li>2. Your Hostel Identity Number is your login to access other features of the site, so keep it safe.</li>
									<li>3. You have to complete your registration so as to book an hostel.</li>
									<li>4. After booking, pay into Account No, using your HID as sender.</li>
									<li>5. Payment will be confirmed within 24 hours. Then you can proceed with your hostel registration</li>
									<li>6. After registration print out the hostel allocation letter.</li>
									<li>7. Submit a copy with a passport-sized photograph to portals lodge close to your allocated block.</li></ol></p>
									</div>
										
				</div>
						</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>