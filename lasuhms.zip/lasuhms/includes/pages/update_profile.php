<div class="panel panel-default">
		<div class="panel-heading">
					<?php echo $myfname;?>, update your Profile
		</div>
</div>										
									<div class="panel-body">
									 
			<form method="post" action="" name="registration" class="form-horizontal" onSubmit="return valid();">
			<div class="form-group">
			<div class="col-sm-10">
				<a href="photo.php">Update Your Profile Photo</a>							
			</div></div>
<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Address Information </h4> </label>
</div>	

<div class="form-group">
<label class="col-sm-2 control-label">Permanent Address :</label>
<div class="col-sm-10">
<input type=text value="<?php echo $myhadd;?>" name="hadd"  id="hadd" class="form-control" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">City : </label>
<div class="col-sm-4">
<input type="text" name="hcity" value="<?php echo $myhcity;?>"  id="hcity" class="form-control" required="required">
</div>

<label class="col-sm-2 control-label">State</label>
<div class="col-sm-4">
<select name="hstate"  id="hstate" value="<?php echo $myhstate;?>" class="form-control" required="required">
              <option value="<?php echo $myhstate;?>" selected="selected"><?php echo $myhstate;?></option>
              <option value="Abuja FCT">Abuja FCT</option>
              <option value="Abia">Abia</option>
              <option value="Adamawa">Adamawa</option>
              <option value="Akwa Ibom">Akwa Ibom</option>
              <option value="Anambra">Anambra</option>
              <option value="Bauchi">Bauchi</option>
              <option value="Bayelsa">Bayelsa</option>
              <option value="Benue">Benue</option>
              <option value="Borno">Borno</option>
              <option value="Cross River">Cross River</option>
              <option value="Delta">Delta</option>
              <option value="Ebonyi">Ebonyi</option>
              <option value="Edo">Edo</option>
              <option value="Ekiti">Ekiti</option>
              <option value="Enugu">Enugu</option>
              <option value="Gombe">Gombe</option>
              <option value="Imo">Imo</option>
              <option value="Jigawa">Jigawa</option>
              <option value="Kaduna">Kaduna</option>
              <option value="Kano">Kano</option>
              <option value="Katsina">Katsina</option>
              <option value="Kebbi">Kebbi</option>
              <option value="Kogi">Kogi</option>
              <option value="Kwara">Kwara</option>
              <option value="Lagos">Lagos</option>
              <option value="Nassarawa">Nassarawa</option>
              <option value="Niger">Niger</option>
              <option value="Ogun">Ogun</option>
              <option value="Ondo">Ondo</option>
              <option value="Osun">Osun</option>
              <option value="Oyo">Oyo</option>
              <option value="Plateau">Plateau</option>
              <option value="Rivers">Rivers</option>
              <option value="Sokoto">Sokoto</option>
              <option value="Taraba">Taraba</option>
              <option value="Yobe">Yobe</option>
              <option value="Zamfara">Zamfara</option>
     <option value="Outside Nigeria">Outside Nigeria</option>
            </select>
</div>
</div>

	<div class="hr-dashed"></div>

<div class="form-group">
<label class="col-sm-6 control-label"><h4 style="color: blue" align="left">Parent/Guidian Info </h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Guardian Name : </label>
<div class="col-sm-4">
<input type="text" name="gurname" id="gurname"  value="<?php echo $mygurname;?>" class="form-control" required="required">
</div>

<label class="col-sm-2 control-label">Relationship : </label>
<div class="col-sm-4">
<input type="text" name="gurrel" id="gurrel" value="<?php echo $mygurrel;?>" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Phone Number : </label>
<div class="col-sm-4">
<input type="text" name="gurphone" id="gurphone"  value="<?php echo $mygurphone;?>" class="form-control" required="required">
</div>
</div>	

						
<div class="form-group">
<label class="col-sm-5 control-label">Permanent address  is same as  Guardian Address: </label>
<div class="col-sm-4">
<input type="checkbox" name="adcheck" value="1"/>
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Address : </label>
<div class="col-sm-10">
<input type="text" name="guradd"  id="guradd" value="<?php echo $myguradd;?>" class="form-control" required="required">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">City : </label>
<div class="col-sm-4">
<input type="text" name="gurcity"  id="gurcity" value="<?php echo $mygurcity;?>"class="form-control" required="required">
</div>
<label class="col-sm-2 control-label">State</label>
<div class="col-sm-4">
<select name="gurstate" id="gurstate"  class="form-control" required="required">
              <option value="<?php echo $mygurstate;?>" selected="selected"><?php echo $mygurstate;?></option>
              <option value="Abuja FCT">Abuja FCT</option>
              <option value="Abia">Abia</option>
              <option value="Adamawa">Adamawa</option>
              <option value="Akwa Ibom">Akwa Ibom</option>
              <option value="Anambra">Anambra</option>
              <option value="Bauchi">Bauchi</option>
              <option value="Bayelsa">Bayelsa</option>
              <option value="Benue">Benue</option>
              <option value="Borno">Borno</option>
              <option value="Cross River">Cross River</option>
              <option value="Delta">Delta</option>
              <option value="Ebonyi">Ebonyi</option>
              <option value="Edo">Edo</option>
              <option value="Ekiti">Ekiti</option>
              <option value="Enugu">Enugu</option>
              <option value="Gombe">Gombe</option>
              <option value="Imo">Imo</option>
              <option value="Jigawa">Jigawa</option>
              <option value="Kaduna">Kaduna</option>
              <option value="Kano">Kano</option>
              <option value="Katsina">Katsina</option>
              <option value="Kebbi">Kebbi</option>
              <option value="Kogi">Kogi</option>
              <option value="Kwara">Kwara</option>
              <option value="Lagos">Lagos</option>
              <option value="Nassarawa">Nassarawa</option>
              <option value="Niger">Niger</option>
              <option value="Ogun">Ogun</option>
              <option value="Ondo">Ondo</option>
              <option value="Osun">Osun</option>
              <option value="Oyo">Oyo</option>
              <option value="Plateau">Plateau</option>
              <option value="Rivers">Rivers</option>
              <option value="Sokoto">Sokoto</option>
              <option value="Taraba">Taraba</option>
              <option value="Yobe">Yobe</option>
              <option value="Zamfara">Zamfara</option>
     <option value="Outside Nigeria">Outside Nigeria</option>
            </select>
</div>
</div>
	<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-4 control-label"><h4 style="color: blue" align="left">Clinic Card ID</h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Clinic ID: </label>
<div class="col-sm-8">
<input type="text" name="cid" id="cid"  value="<?php echo $mycid;?>" class="form-control">
</div>
</div>

	<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="update" value="Update Details" class="btn btn-primary">
</div>
</form>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
