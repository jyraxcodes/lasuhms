<center><h2 class="page-title">Update your Profile Picture</h2></center>

						<div class="row">
							<div class="col-md-12">
								<div class="col-md-12">
									<div class="panel panel-default">
										
									</div>
									<div class="hr-dashed"></div>
									
<form method="POST" enctype="multipart/form-data" >
              <div class="col-md-4" style="float: right;">
    <img class="profile-img " name="imageupload" src="img/user.png" alt="profile picture" style="height:100px;width:100px;" class="form-control">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <input type="file" name="profile_pic" >
        </div>
		    <div class="box-footer">
           <button type="submit"  name="Save" class="btn btn-success bg-green" ><i class="fa fa-file-text"></i> Save</button>
           <button type="reset"  name="reset" class="btn btn-primary" value="reset"><i class="f fa fa-undo"></i> Reset</button>
          
          </div>
		
</div></div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div></div>