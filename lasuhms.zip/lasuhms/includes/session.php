<?php
function session_start_timeout($timeout=5, $probability=100, $cookie_domain='/') {
 // Set the max lifetime
 ini_set("session.gc_maxlifetime", $timeout);
 // Set the session cookie to timout
 ini_set("session.cookie_lifetime", $timeout);
 $seperator = strstr(strtoupper(substr(PHP_OS, 0, 3)), "WIN") ? "\\" : "/";
 $path = ini_get("session.save_path") . $seperator . "session_" . $timeout . "sec";
 if(!file_exists($path)) {
 if(!mkdir($path, 600)) {
 trigger_error("Failed to create session save path directory '$path'. Check permission");
 }
 }
 ini_set("session.save_path", $path);
 // Set the chance to trigger the garbage collection.
 ini_set("session.gc_probability", $probability);
 ini_set("session.gc_divisor", 100); // Should always be 100
 // Start the session!
 session_start_timeout(60, 10);
 if(isset($_COOKIE[session_name()])) {
 setcookie(session_name(), $_COOKIE[session_name()], time() + $timeout, $cookie_domain
 }
}
?>