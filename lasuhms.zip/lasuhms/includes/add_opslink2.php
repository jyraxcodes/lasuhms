<?php
include('config.php');
//code for add hostel

$operational_code=$_POST['operational_code'];

$query="update  registration set hadd=?,hcity=?,hstate=?,gurname=?,gurrel=?,gurphone=?,guradd=?,gurcity=?,gurstate=?,cid=? where hid=?";

if(isset($_POST['submit1']))
{
$operational_name='Prebooking';
$studregstat=$_POST['studregstat'];
if ($studregstat=="OFF"){
	$query11="UPDATE operational_links  SET operational_code=? WHERE operational_name=?";
		if(mysqli_query($mysqli,$query11));
			$stmt11 = $mysqli->prepare($query11);
			$rc11=$stmt11->bind_param('is',$operational_code,$operational_name);
			$stmt11->execute();
			echo"<script>alert('Students Registration  has been Turned ON. Reload the page.');</script>";
		}elseif($studregstat=="ON"){
		if(mysqli_query($mysqli,$query12));
		$query12="DELETE operational_code FROM operational_links WHERE operational_name=?";
			$stmt12 = $mysqli->prepare($query12);
			$rc12=$stmt12->bind_param('is',$operational_code,$operational_name);
			$stmt12->execute();
			echo"<script>alert('Students Registration has been Turned OFF.  Reload the page.');</script>";
	}else{
	echo"<script>alert('Opslink failed successfully');</script>";
}
}
if(isset($_POST['submit2']))
	{
$prebookstat=$_POST['prebookstat'];
if ($prebookstat=="OFF"){
		if(mysqli_query($mysqli,"INSERT INTO  operational_links (operational_code,operational_name) VALUES('10002','Prebooking')"));
			echo"<script>alert('Prebooking  has been Turned ON. Reload the page.');</script>";
	}elseif($prebookstat=="ON"){
		if(mysqli_query($mysqli,"DELETE FROM operational_links WHERE operational_code ='10002'"));
			echo"<script>alert('Prebooking has been Turned OFF. Reload the page. ');</script>";
			}else{
	echo"<script>alert('Prebooking failed successfully');</script>";
}
}
if(isset($_POST['submit3']))
{
$bookinstat=$_POST['bookinstat'];
	if ($bookinstat=="OFF"){
			if(mysqli_query($mysqli,"INSERT INTO  operational_links (operational_code,operational_name) VALUES('10003','Booking')"));
			echo"<script>alert('Booking and Registration have been Turned ON. Reload the page.');</script>";
	}elseif($bookinstat="ON"){
		if(mysqli_query($mysqli,"DELETE FROM operational_links WHERE operational_code ='10003'"));
			echo"<script>alert('Booking has been Turned OFF. Reload the page. ');</script>";
			}else{
	echo"<script>alert('Booking failed successfully');</script>";
}
}

?>