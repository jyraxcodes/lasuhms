<?php
include('pdoconfig.php');
session_start();
if(!empty($_POST["hosteladd1"])) 
{	
$id=$_POST['hosteladd1'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['blockno']); ?>
  <?php
 }
}

if(!empty($_POST["hosteladd2"])) 
{	
$id=$_POST['hosteladd2'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['flatno']); ?>
  <?php
 }
}

if(!empty($_POST["hosteladd3"])) 
{	
$id=$_POST['hosteladd3'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['roomno']); ?>
  <?php
 }
}

if(!empty($_POST["hosteladd4"])) 
{	
$id=$_POST['hosteladd4'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['block_type']); ?>
  <?php
 }
}



if(!empty($_POST["hosteladd5"])) 
{	
$id=$_POST['hosteladd5'];
$stmt =$DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['sex']); ?>
  <?php
 }
}

if(!empty($_POST["hosteladd6"])) 
{	
$id=$_POST['hosteladd6'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['status']); ?>
  <?php
 }
}


if(!empty($_POST["hosteladd7"])) 
{	
$id=$_POST['hosteladd7'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['seater']); ?>
  <?php
 }
}


if(!empty($_POST["hosteladd8"])) 
{	
$id=$_POST['hosteladd8'];
$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE hosteladd = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['fees']); ?>
  <?php
 }
}
		if(!empty($_POST["roomno"])) 
			{	
			$blockno=$_POST['blockno'];
			$flatno=$_POST['flatno'];
			$roomno=$_POST['hosteladd8'];
			$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE blockno= :$blockno AND flatno= :$flatno AND roomno= :$roomno");
			$stmt->execute(array(':id' => $id));
				?>
			<?php
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		{
			?>
 <?php echo htmlentities($row['hosteladd1']); ?>
  <?php
 }
}
		if(!empty($_POST["flatno"])) 
			{	
			$blockno=$_POST['blockno'];
			$flatno=$_POST['flatno'];
			$stmt = $DB_con->prepare("SELECT * FROM hostel WHERE blockno= :$blockno AND flatno= :$flatno");
			$stmt->execute(array(':id' => $id));
				?>
			<?php
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		{
			?>
 <?php echo htmlentities($row['hosteladd2']); ?>
  <?php
 }
}



if(!empty($_POST["dept"])) 
{	
$id=$_POST['dept'];
$stmt = $DB_con->prepare("SELECT * FROM department WHERE dept = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['faculty']); ?>
  <?php
 }
}


if(!empty($_POST["seater"])) 
{	
$id=$_POST['seater'];
$stmt = $DB_con->prepare("SELECT * FROM hostelcat WHERE seater = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['fees']); ?>
  <?php
 }
}


if(!empty($_POST["block_type"])) 
{	
$id=$_POST['block_type'];
$stmt = $DB_con->prepare("SELECT * FROM hostelcat WHERE blocktype ='PDS Halls'");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['fees']); ?>
  <?php
 }
}


?>