<?php 
$prebookcount=0;
$prebook=10002;
$resultp="SELECT count(*) FROM operational_links WHERE operational_code=?";
$stmt =$mysqli->prepare($resultp);
$stmt->bind_param('i',$prebook);
$stmt->execute();
$stmt->bind_result($prebookcount);
$stmt->fetch();
$stmt->close();
	
?>