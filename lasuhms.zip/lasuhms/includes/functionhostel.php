<?php 
$ret="select * from hostel where hosteladd =$input";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$mblock_type=$row['block_type'];
	$mblockno=$row['blockno'];
	$mflatno=$row['flatno'];
	$mroomno=$row['roomno'];
	$mstatus=$row['status'];
	$mseater=$row['seater'];
	$msex=$row['sex'];
	$mfees=$row['fees'];
}
?>