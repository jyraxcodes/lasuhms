<?php
include('config.php');
//code for add hostel
if(isset($_POST['submit'])){
$hosteladd=$_POST['hosteladd'];
$blockno=$_POST['blockno'];
$flatno=$_POST['flatno'];
$roomno=$_POST['roomno'];
$block_type=$_POST['block_type'];
$sex=$_POST['sex'];
$status=$_POST['status'];

$query="INSERT INTO  hostel (hosteladd,blockno,flatno,roomno,block_type,sex,status) VALUES(?,?,?,?,?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('siiisss',$hosteladd,$blockno,$flatno,$roomno,$block_type,$sex,$status);
$stmt->execute();
echo"<script>alert('Room/Flat has been added successfully');</script>";
}

?>