									<div class="row">
									<div class="col-md-12">	
									<div class="panel-body">
									<section class="content">
      <div class="error-page">
	  <h2 class="headline fa fa-warning text-blue"></h2>

        <div class="error-content">
          <h3><i class="icon ion-person text-blue"></i>Incomplete Profile</h3>

          <p>Complete your profile to use this facility.   </p>

          </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>
	</div>
	</div>
	</div>