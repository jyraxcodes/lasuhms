<?php
include"config.php";
include"my.php";

		
if(isset($_POST['submit']))
{
$hosteladd=$_POST['hosteladd'];
$block_type=$_POST['block_type'];
$seater=$_POST['seater'];
$fees=$_POST['fees'];

$query="INSERT INTO  temp_booking (hid,hosteladd,block_type,seater,fees) VALUES(?,?,?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('issii',$myhid,$hosteladd,$block_type,$seater,$fees);
$stmt->execute();
echo"<script>alert('Your hostel choice has being added successfully');</script>";
}

?>