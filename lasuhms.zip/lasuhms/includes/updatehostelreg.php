<?php 
include('config.php');
if(isset($_POST['update']))
{
$level=$_POST['level'];
$item1=$_POST['item1'];
$item2=$_POST['item2'];
$item3=$_POST['item3'];
$item4=$_POST['item4'];

$query1="UPDATE  hostelreg SET level=?, item1=?, item2=?, item3=?, item4=? WHERE hid=?";
$stmt = $mysqli->prepare($query1);
$rc=$stmt->bind_param('sssssi',$level,$myhid,$item1,$item2,$item3,$item4,$myhid);
$stmt->execute();
echo"<script>alert('Hostel Registration Completed Successfully');</script>";
}
?>