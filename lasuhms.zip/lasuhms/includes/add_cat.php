<?php
include('config.php');
//code for add hostel

if(isset($_POST['submit']))
{
$block_type=$_POST['block_type'];
$seater=$_POST['seater'];
$fees=$_POST['fees'];
$query="INSERT INTO  hostelcat (block_type,seater,fees) VALUES(?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('sii',$block_type,$seater,$fees);
$stmt->execute();
echo"<script>alert('Block type has been added successfully');</script>";
}else{
	echo"<script>alert('Block type failed successfully');</script>";
}

?>