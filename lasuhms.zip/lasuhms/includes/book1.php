<?php
include"config.php";
include"my.php";

		
if(isset($_POST['submit']))
{
$reghosteladd=$_POST['hosteladd'];

$ret="select * from hostel where hosteladd=$reghosteladd";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$regblocktype=$row['block_type'];
	$regblockno=$row['blockno'];
	$regflatno=$row['flatno'];
	$regroomno=$row['roomno'];
	$regstatus=$row['status'];
	$regseater=$row['seater'];
	$regfees=$row['fees'];
	$regstatus=$row['status'];
	$regsex=$row['sex'];
}
									if($regblocktype=='PDS halls' and $myprogram!='PDS'){
										$msg="You can't register PDS hostels";
									}elseif($myprogram=='PDS' and $regblocktype=='Old Hostels'){ 
										$msg="You can only register  PDS Halls";
									}elseif($myprogram=='PDS' and $regblocktype=='New Hostels'){
										$msg="You can only register  PDS Halls";
									}elseif($gender!=$regsex){
										$msg="You can't register Opposite sex hostels";
									}elseif ($regstatus!="Good"){
										$msg="You can't register Damaged/Official Hostels";
									}else{
	$hosteladd=$reghosteladd;
	$block_type=$regblocktype;
	$seater=$regseater;
	$fees=$regfees;

$query="INSERT INTO  bookings (hid,hosteladd,block_type,seater,fees) VALUES(?,?,?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('issii',$myhid,$hosteladd,$block_type,$seater,$fees);
$stmt->execute();
echo"<script>alert('Your hostel choice has being added successfully');</script>";
}
}
?>