									<div class="row">
									<div class="col-md-12">	
									<div class="panel-body">
									<section class="content">
      <div class="error-page">
        <h2 class="headline fa fa-warning text-red"></h2>

        <div class="error-content">
          <h3>"<?php echo $page;?>" Period Is Over</h3>

          <p>Sorry,The period to use this facility is over. 
          </p>

          </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>
	</div>
	</div>
	</div>