<div class="panel-heading">
					<div class="announcement">
					<div class="announcementlabel"><font size="2"><b><i>Announcements</i></b></font></div>
					<div class="announcementnews"><marquee><font size="2"><b><i>Announcements for the Students </i></b></font></marquee> </div></div>
						</div>