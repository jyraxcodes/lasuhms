				<?php
		if(isset($_SESSION['hid']))
{ ?>
<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
			
					<li class="ts-label">Main Navigation</li>

					<li><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
					<li><a href="#"><i class="fa fa-user"></i> Profile</a>
					<ul>
						<li><a href="profile.php">View Profile</a></li>
						
						<li><a href="completereg.php">Complete Registration</a></li>
						<li><a href="editprofile.php">Update Profile</a></li>
						<li><a href="hostelrecord.php">Hostel Records</a></li>
					</ul>
				</li>
				<li><a href="#"><i class="fa fa-files-o"></i> Hostel Management</a>
					<ul>
						<li><a href="prebook.php">Prebook Hostel</a></li>
						<li><a href="registration.php">Continue Hostel Registration</a></li>
						<li><a href="letter.php">Print Hostel Allocation Letter</a></li>
					</ul>
				</li>
				<li><a href="hostelrules.php"><i class="fa fa-files-o"></i>Hostel Regulations</a></li>
				<li><a href="dressmode.php"><i class="fa fa-files-o"></i>Mode of Dressing</a></li>
				<li><a href="logout.php"><i class="fa fa-arrow-left"></i>Logout <?php echo $row['fname']; ?></a></li>

			</ul>
		</nav>
	<?php
} else { ?>
<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">

				<li class="ts-label">Main Navigation</li>

					<li><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
					<li><a href="login.php"><i class="fa fa-users"></i> Students Login</a></li>
					<li><a href="signup.php"><i class="fa fa-users"></i> Students Registration</a></li>
					<li><a href="hostelrules.php"><i class="fa fa-files-o"></i>Hostel Regulations</a></li>
						<li><a href="dressmode.php"><i class="fa fa-files-o"></i>School Dressing Rule</a></li>
						<li><a href="news.php"><i class="fa fa-files-o"></i>News</a></li>
			</ul>
		</nav>
		<?php } ?>