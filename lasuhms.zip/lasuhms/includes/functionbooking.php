<?php 
$booking=10003;
$results ="SELECT count(*) FROM operational_links WHERE operational_code=?";
$stmt =$mysqli->prepare($results);
$stmt->bind_param('i',$booking);
$stmt->execute();
$stmt->bind_result($bookingcount);
$stmt->fetch();
$stmt->close();

?>