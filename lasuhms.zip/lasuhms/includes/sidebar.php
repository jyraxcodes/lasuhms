<?php
 

		if(!isset($_SESSION['hid']))
{ 

include('functionregistration.php');
?>
			<ul class="ts-sidebar-menu">
			
								<li class="ts-label">Main Navigation</li>

					<li><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
					<?php 
					if($regcount>0){?>
					<li><a href="signup.php"><i class="fa fa-users"></i> Students Registration</a></li>
					<li><a href="login.php"><i class="fa fa-users"></i> Students Login</a></li>
					<?php }else{?>
					<li><a href="login.php"><i class="fa fa-users"></i> Students Login</a></li>
					<?php } ?>
					<li><a href="hostelrules.php"><i class="fa fa-files-o"></i>Hostel Regulations</a></li>
					<li><a href="dressmode.php"><i class="fa fa-files-o"></i>School Dressing Rule</a></li>
					<li><a href="news.php"><i class="fa fa-files-o"></i>News</a></li>
</ul>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>

<style> .foot{color:#fff; text-align: center;}</style>
</ul>

		
		<?php }else{ ?>
		
	<?php include('functionprebook.php');
include('functionbooking.php');	
?>
			<ul class="ts-sidebar-menu">
			
			<div class="user-panel">
        <div class="pull-left image">
          <?php if ($mypics==""){
                echo '<img class="img-circle" alt="User Avatar" src="img/user.jpg">';
              }else{
				  echo '<img class="img-circle" alt="'.$mylname.'" src="student/'.$mypics.'">';}?>
        </div>       
          <li><a href="#"> &nbsp;<?php echo $myfname.' '.$mylname;?></a>
				<ul>
					<li><a href="profile.php">My Account</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
				</li>
   
      </div>
				
					<li class="ts-label">Main Navigation</li>

					<li><a href="dashboard.php"><i class="fa fa-home"></i>Dashboard</a></li>
					 <?php if ($mydob=""){
							 echo '<li><a href="completereg.php"><i class="fa fa-user"></i>Complete Registration</a></li>';
						 }else{?>
					<li><a href="#"><i class="fa fa-user"></i> Profile</a>
					<ul>
						<li><a href="profile.php">View Profile</a></li>
						<li><a href="editprofile.php">Update Profile</a></li>
					</ul>
				</li>
				<?php }?>
				<li><a href="#"><i class="fa fa-files-o"></i> Hostel Management</a> 
					<ul>
					<?php 
						if($prebookcount>0){?>
						<li><a href="prebook.php">Prebook Hostel</a></li>
						<?php }elseif($bookingcount>0){?>
							<li><a href="book_hostel.php">Book a Hostel</a></li>
							<li><a href="registration.php">Continue Hostel Registration</a></li>
							<li><a href="hostelrecord.php">Hostel Records</a>
							</li><?php }else{?>
							<li><a href="hostelrecord.php">Hostel Records</a></li>
						<?php }?>
						<?php if($myhosteladd!=""){?>
						<li><a href="letter.php">Hostel Allocation Letter</a></li>
						<?php }else{?>
						<li><a href="#">No Hostel Allocation Letter</a></li>
						<?php }?>
					</ul>
				</li>
				<li><a href="dressmode.php"><i class="fa fa-files-o"></i>Mode of Dressing</a></li>
				<li><a href="news.php"><i class="fa fa-files-o"></i>News</a></li>
		
</ul>
<br />
<br />
<br />
<br />
<br />
<br />
		<div class="foot"><footer>
<p> &copy;<?php  echo date('Y');?> <a href="https://lasu.edu.ng/">Lagos State University, Ojo.</a></p>
</footer> </div>


<style> .foot{color:#fff; text-align: center;}</style>
		<?php } ?>
