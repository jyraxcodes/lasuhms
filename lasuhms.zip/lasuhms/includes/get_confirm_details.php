<?php
include('pdoconfig.php');
session_start();
if(!empty($_POST["hid1"])) 
{	
$id=$_POST['hid1'];
$stmt = $DB_con->prepare("SELECT * FROM bookings WHERE hid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['hosteladd']); ?>
  <?php
 }
}

if(!empty($_POST["hid2"])) 
{	
$id=$_POST['hid2'];
$stmt = $DB_con->prepare("SELECT * FROM bookings WHERE hid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['block_type']); ?>
  <?php
 }
}

if(!empty($_POST["hid3"])) 
{	
$id=$_POST['hid3'];
$stmt = $DB_con->prepare("SELECT * FROM bookings WHERE hid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['seater']); ?>
  <?php
 }
}


if(!empty($_POST["hid4"])) 
{	
$id=$_POST['hid4'];
$stmt = $DB_con->prepare("SELECT * FROM bookings WHERE hid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['fees']); ?>
  <?php
 }
}

?>