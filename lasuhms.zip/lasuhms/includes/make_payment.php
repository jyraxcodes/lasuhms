									<div class="row">
									<div class="col-md-12">	
									<div class="panel-body">
									<section class="content">
      <div class="error-page">
	  <h2 class="headline fa fa-warning text-blue"></h2>

        <div class="error-content">
          <h3><i class="icon ion-person text-blue"></i>Error</h3>

          <p>Make Payment to use this facility. And after payment if the error still persist within 24 hour, visit the Students' Affairs Office   </p>

          </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>
	</div>
	</div>
	</div>