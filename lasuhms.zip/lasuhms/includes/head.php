<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="Dashboard page to see updates and Notice">
	<meta name="author" content="Alagbe Sunmbo Amos">
	<meta name="theme-color" content="#3e454c">
	<title><?php echo $page;?> :: Lagos State University Hostels</title>
	<link href="images/favicon.gif" rel="shortcut icon" type="image/vnd.microsoft.icon">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
</head>
<body>
<?php include ("includes/header.php");?>
	<div class="ts-main-content">
		<nav class="ts-sidebar">
		<?php include ("includes/sidebar.php");?>
	</nav>
			<div class="content-wrapper">
			<br />
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					
						<div class="panel panel-primary">
					
							<div class="panel-body">