<?php
//Start session:
session_start();

//Include db settings and create a connection:
include("config.php");

//Create variable for hid input and prevent sql injections:
$hid = mysqli_real_escape_string($_POST['hid']);
//Create variable for password input, prevent sql injections and hash it with md5:
$password = mysqli_real_escape_string($_POST['password']);

//Select matching hid and password from admin table based on input:
$sql = "SELECT * FROM userreg WHERE hid = '$hid' AND password = '$password'";
//Execute query to db:
$execute = mysqli_query($mysqli,$sql);

//If user input doesn't match a user in db:
if (mysqli_num_rows($execute) != 1 && $_SERVER["REQUEST_METHOD"] == "POST") {
    //Create error message:
    $errormsg = "<p><span class='errormsg'>The hid and/or password you entered was incorrect!</span></p>";
}
//Else if user exists in db:
else if (mysqli_num_rows($execute) == 1) {
    //Set hid session variable based on hid input:
    $_SESSION['hid'] = $hid;
}
//If user is already logged in, redirect to admin page:
if (isset($_SESSION['hid'])) {
    header('Location: dashboard.php');
}