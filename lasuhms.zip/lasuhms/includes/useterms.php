									<br />
									<div class="row">
									<div class="col-md-12">	
									<div class="panel-body">
									<section class="content">
      <div class="error-page">
	  <h2 class="headline fa fa-warning text-blue"></h2>

        <div class="error-content">
          <h3><i class="fa fa-warning text-blue"></i> Use the Facility Once</h3>

          <p>Sorry, You can only use this facility once. If you have error in your registration, please visit Students Affairs 
          </p>

          </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>
	</div>
	</div>
	</div>