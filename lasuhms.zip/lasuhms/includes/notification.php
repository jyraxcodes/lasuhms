
				<div class="col-md-4">
          <div class="box box-success box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Notification (<?php echo $noticount; ?>)</h3>

             <?php if($noticount>0){
				?>
				<div class="box-tools pull-right">
                <a href="dashboard.php?del=<?php echo $notiid;?>" onclick="return confirm('Do you want to delete');"><i class="fa fa-times"></i></a>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <center><b><?php echo $notititle; ?></b><br /><i><?php echo $notitime; ?></center></i><br />
            <?php echo $notibody; ?>
			<center>--------END--------</center>
            </div>
			 <?php}else{?>
			 <div class="box-tools pull-right">
               
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->

			<?php
			 }?>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->