<?php
include('config.php');
if (isset($_SESSION['hid'])){
$aid=$_SESSION['hid'];
$ret="select * from userreg where hid=$aid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$myhid=$row['hid'];
$myfname=$row['fname'];
$myoname=$row['oname'];
$mylname=$row['lname'];
$gender=$row['sex'];
$myphone=$row['phone'];
$myemail=$row['email'];
$myprogram=$row['programme'];
}

}
$result ="SELECT count(*) FROM registration WHERE hid=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$myhid);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
if($count<1){
$mydob="";
$myhadd="";
$myhcity="";
$myhstate="";
$mygurname="";
$mygurrel="";
$mygurphone="";
$myguradd="";
$mygurcity="";
$mygurstate="";
$mymatricno="";
$mydept="";
$myfac="";
$mycid="";
$mypics="";
}else{
$ret="select * from registration where hid=$myhid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$mydob=$row['dob'];
$myhadd=$row['hadd'];
$myhcity=$row['hcity'];
$myhstate=$row['hstate'];
$mygurname=$row['gurname'];
$mygurrel=$row['gurrel'];
$mygurphone=$row['gurphone'];
$myguradd=$row['guradd'];
$mygurcity=$row['gurcity'];
$mygurstate=$row['gurstate'];
$mymatricno=$row['matricno'];
$mydept=$row['dept'];
$myfac=$row['faculty'];
$mycid=$row['cid'];
$mypics=$row['imagename'];
}
}



$result ="SELECT count(*) FROM notifications WHERE hid=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$myhid);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
$noticount=$count;
if($noticount<1){
	$notibody="No Notification";
}else{
	$ret="select * from notifications where hid=$myhid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$notiid=$row['id'];
	$notititle=$row['title'];
	$notibody=$row['message'];
	$notitime=$row['time'];
}
}

$ret="select * from session where session_id=0";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$session=$row['year1']."/".$row['year2'];
	$asi=$row['signature'];
}
	


$ret="select * from admin where designation='admin'";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$sadminfname=$row['afname'];
	$sadminlname=$row['alname'];
}
	

$result ="SELECT count(*) FROM bookings WHERE hid=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$myhid);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
if($count<1){
	
$bkhosteladd="";
}else{
$ret="select * from bookings where hid=$myhid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$bkhhid=$row['hid'];
$bkhosteladd=$row['hosteladd'];
}
}


if ($bkhosteladd!=""){
$ret="select * from hostel where hosteladd=$bkhosteladd";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$bkblocktype=$row['block_type'];
	$bkblockno=$row['blockno'];
	$bkflatno=$row['flatno'];
	$bkroomno=$row['roomno'];
	$bkstatus=$row['status'];
	$bkseater=$row['seater'];
	$bksex=$row['sex'];
	$bkfees=$row['fees'];
}	
}else{
	$bkblocktype="";
	$bkblockno="";
	$bkflatno="";
	$bkroomno="";
	$bkstatus="";
	$bkseater="";
	$bksex="";
	$bkfees="";
	$bkhhid="";
	$bkhosteladd="";
}


$result ="SELECT count(*) FROM hostelreg WHERE hid=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$myhid);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
if($count<1){
$myhosteladd="";
$mylevel="";
$myhosteladd="";
$myregdate="";
}else{
$ret="select * from hostelreg where hid=$myhid";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
$myhhid=$row['hid'];
$myhosteladd=$row['hosteladd'];
$mylevel=$row['level'];
$myhosteladd=$row['hosteladd'];
$myregdate=['date'];
}
}


if ($myhosteladd!=""){
$ret="select * from hostel where hosteladd=$myhosteladd";
$result=mysqli_query($mysqli,$ret);
while ($row=mysqli_fetch_array($result))
{
	$myblocktype=$row['block_type'];
	$myblockno=$row['blockno'];
	$myflatno=$row['flatno'];
	$myroomno=$row['roomno'];
	$mystatus=$row['status'];
	$myseater=$row['seater'];
	$mysex=$row['sex'];
	$myfees=$row['fees'];
}	
}else{
	$myblocktype="";
	$myblockno="";
	$myflatno="";
	$myroomno="";
	$mystatus="";
	$myseater="";
	$mysex="";
	$myfees="";
	$myhhid="";
	$myhosteladd="";
	$mylevel="";
	$myregdate="";
}

$result ="SELECT count(*) FROM bookings WHERE hid=?";
$stmt =$mysqli->prepare($result);
$stmt->bind_param('i',$myhid);
$stmt->execute();
$stmt->bind_result($bkcount);
$stmt->fetch();
$stmt->close();
	
$ret="select * from session";
$stmt= $mysqli->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
		  $session=$row->year1.'/'.$row->year2;
		  $sadminsign=$row->signature;
	  }
?>
