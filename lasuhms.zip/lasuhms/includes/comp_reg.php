<?php 
include('config.php');
if(isset($_POST['submit']))
{
	if($_FILES["profile_pic"]["name"]!='')
  {
   
$target_dir="students/";
$imgname=$_FILES["profile_pic"]["name"];
$type = $_FILES["profile_pic"]["type"];
$size = $_FILES["profile_pic"]["size"];

$temp = $_FILES["profile_pic"]["tmp_name"]; 
$error = $_FILES["profile_pic"]["error"];//size
  if($error>0)
  {
    die("Error uploading file! Code $error.");
  }
  else
  { 
    if ($type=="images/" || $size > 5000000)
    {
      die("that format is not allowed or file size is too big!");
    }
    else
    { //echo "string"; exit;
     move_uploaded_file($temp,"student/".$imgname); 
     // echo"Upload Complete";  
    }
  }
    } 
    else
    {
      
    }
	
$hid=$_SESSION['hid'];
$dob=$_POST['dob'];
$hadd=$_POST['hadd'];
$hcity=$_POST['hcity'];
$hstate=$_POST['hstate'];
$matricno=$_POST['matricno'];
$dept=$_POST['dept'];
$faculty=$_POST['fac'];
$gurname=$_POST['gurname'];
$gurrel=$_POST['gurrel'];
$gurname=$_POST['gurname'];
$gurphone=$_POST['gurphone'];
$guradd=$_POST['guradd'];
$gurcity=$_POST['gurcity'];
$gurstate=$_POST['gurstate'];
$cid=$_POST['cid'];
	   
$write =mysqli_query($mysqli,"INSERT INTO  registration(`hid`,`dob`,`hadd`,`hcity`,`hstate`,`matricno`,`dept`,`faculty`,`gurname`,`gurrel`,`gurphone`,`guradd`,`gurcity`,`gurstate`,`cid`,`imagename`) VALUES
	 ('$hid','$dob',$hadd','$hcity','$hstate','$matricno','$dept','$faculty','$gurname','$gurrel','$gurphone','$guradd','$gurcity','$gurstate','$cid','$imgname')") or die(mysqli_error($mysqli));
      //$query=mysql_query("SELECT * FROM user ")or die (mysql_error());
      //$numrows=mysql_num_rows($query)or die (mysql_error());
     echo " <script>setTimeout(\"location.href='dashborad.php';\",150);</script>";
}
    
?>