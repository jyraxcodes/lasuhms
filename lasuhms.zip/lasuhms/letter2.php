<?php
 session_start();
include"includes/config.php";
include"includes/checklogin.php";
include"includes/my.php";
include('libs/phpqrcode/qrlib.php'); 

if(isset($_POST['submit']) ) {
	$tempDir = 'temp/'; 
	$filename = "Special";
	$body =  $_POST['msg'];
	$codeContents = '&body='.urlencode($body); 
	QRcode::png($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
}
$page='Allocation Letter';
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title><?php echo $page;?> :: Lagos State University Hostels</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
</head>
<body>


							<div class="row">
							<div class="col-md-12">	
							<img src="img/letterheader.gif">
									<div class="print">
					
			<?php
			if(!isset($filename)){
				$filename = "author";
			}
			?>
			<center><h3><b><?php echo $session;?> Session</b></h3></center>
			<div class="form-group">
				     <div class="col-md-4" style="float: right;">
					 
			<center><b><?php echo date('d M, Y');?></b><br />

<i>QR Comfirmation</i>

							<?php echo '<img src="temp/'. @$filename.'.png" style="width:150px; height:150px;"><br>'; ?>
					</center>
					
</div>
</div>
	&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;<p><b>TO:</b>&nbsp; <b><?php echo $myfname.' '.$mylname; ?></b>,<br/>
	&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $myhadd; ?></b>,<br/>
	&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;<b> <?php echo $myhcity.', '. $myhstate; ?>.</b></p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<p>&nbsp;&nbsp;&nbsp; This is to confirm that <?php if ($mysex=="Male"){ echo 'Mr';}else{echo 'Miss';}?> <b><?php echo ucfirst($myfname.'&nbsp;'.$myoname .'&nbsp;'.$mylname);?></b> with Hostel Identity No <b><?php echo ucfirst($myhid);?></b> and Matric Number <b>
<?php echo ucfirst($mymatricno);?></b> of the <b><?php echo ucfirst($mydept); ?> </b> in the Faculty of <b><?php echo ucfirst($myfac);?> </b>has been allocated to Block <b><?php echo ucfirst($myblockno);?></b>, <?php if ($myblocktype=="Old Hostels"){?>
					Flat <b><?php echo ucfirst($myflatno);?></b>, Room <b><?php echo ucfirst($myroomno);?></b>.<?php }else{?>
			Flat <b><?php echo ucfirst($myflatno);}?></b></p>
			<p>&nbsp;&nbsp;&nbsp; You are advised to take good care of the hostel's materials and environment.</p>
			Thanks<br/>
			
			
			
			<img src="img/<?php echo $asi;?>" /><br />
			__________________________<br />
			<b><?php echo $sadminfname.'&nbsp;'. $sadminlname; ?></b></br>
			Head, Students Affairs Units
			</font>
						
<b>Note:</b><i>Do Not refresh the page before printing.</i>
</div>
</div>			
</div>
</div>
</body>
</html>